package com.bazigar.bulandawaaz

import android.app.Application
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.camera.camera2.Camera2Config
import androidx.camera.core.CameraXConfig
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.utils.DataStoreKeys
import com.google.android.exoplayer2.database.ExoDatabaseProvider
import com.google.android.exoplayer2.upstream.cache.LeastRecentlyUsedCacheEvictor
import com.google.android.exoplayer2.upstream.cache.SimpleCache

import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class App:Application(), CameraXConfig.Provider{

    @Inject
    lateinit var appDataStore: AppDataStore


    companion object {
        lateinit var simpleCache: SimpleCache
        const val exoPlayerCacheSize: Long = 90 * 1024 * 1024
        lateinit var leastRecentlyUsedCacheEvictor: LeastRecentlyUsedCacheEvictor
        lateinit var exoDatabaseProvider: ExoDatabaseProvider // todo: update afterwords
    }


    override fun onCreate() {
        super.onCreate()
//        FirebaseApp.initializeApp(applicationContext);
//
//        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
//            if (!task.isSuccessful) {
//                Log.w("TAG", "Fetching FCM registration token failed", task.exception)
//                return@OnCompleteListener
//            }
//            // Get new FCM registration token
//            val token = task.result?:""
//            // Log
//            Log.d("TAG", "Fcm Token is $token")
//
//            //save into datastore
//
//            GlobalScope.launch(IO) {
//                if (token.isNotBlank()) {
//                    appDataStore.setValue(DataStoreKeys.FIREBASE_TOKEN, token)
//                } else {
//                    appDataStore.setValue(DataStoreKeys.FIREBASE_TOKEN, "")
//                }
//            }
//        })


        GlobalScope.launch {

            appDataStore.setValue(DataStoreKeys.FIREBASE_TOKEN, "")
        }
        leastRecentlyUsedCacheEvictor = LeastRecentlyUsedCacheEvictor(exoPlayerCacheSize)
        exoDatabaseProvider = ExoDatabaseProvider(this)
        simpleCache = SimpleCache(cacheDir, leastRecentlyUsedCacheEvictor, exoDatabaseProvider)
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun getCameraXConfig(): CameraXConfig {
        return CameraXConfig.Builder.fromConfig(Camera2Config.defaultConfig())
            .setMinimumLoggingLevel(Log.ERROR).build()
    }
}