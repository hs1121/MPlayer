package com.bazigar.bulandawaaz.business.caching

import android.R
import android.content.Context
import com.bazigar.bulandawaaz.App
import com.google.android.exoplayer2.upstream.*
import com.google.android.exoplayer2.upstream.cache.CacheDataSink
import com.google.android.exoplayer2.upstream.cache.CacheDataSource
import com.google.android.exoplayer2.upstream.cache.LeastRecentlyUsedCacheEvictor
import com.google.android.exoplayer2.upstream.cache.SimpleCache
import com.google.android.exoplayer2.util.Util
import java.io.File
import javax.inject.Inject


class CacheDataSourceFactory(context: Context, maxCacheSize: Long, maxFileSize: Long) :
    DataSource.Factory {
    private val context: Context = context
    private val defaultDatasourceFactory: DefaultDataSourceFactory
    private val maxFileSize: Long = maxFileSize
    private val maxCacheSize: Long = maxCacheSize
    private val simpleCache:SimpleCache = App.simpleCache

    override fun createDataSource(): DataSource {

        return CacheDataSource(
            simpleCache, defaultDatasourceFactory.createDataSource(),
            FileDataSource(), CacheDataSink(simpleCache, maxFileSize),
            CacheDataSource.FLAG_BLOCK_ON_CACHE or CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR,null
        )
    }

    init {
        val userAgent: String = Util.getUserAgent(context, context.getString(com.bazigar.bulandawaaz.R.string.app_name))
        val bandwidthMeter = DefaultBandwidthMeter.Builder(context).build()
        defaultDatasourceFactory = DefaultDataSourceFactory(
            this.context,
            bandwidthMeter,
            DefaultHttpDataSource.Factory().apply {
                setUserAgent(userAgent)
            }

        )
    }
    inner class CacheDataSourceListener :CacheDataSource.EventListener{
        override fun onCachedBytesRead(cacheSizeBytes: Long, cachedBytesRead: Long) {
            TODO("Not yet implemented")
        }

        override fun onCacheIgnored(reason: Int) {
            TODO("Not yet implemented")
        }

    }
}