package com.bazigar.bulandawaaz.business.datasource

import android.content.Context
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.business.datasource.network.home.HomeService
import com.bazigar.bulandawaaz.business.datasource.pagingsource.HomePagingSource
import com.bazigar.bulandawaaz.business.datasource.pagingsource.ProfilePagingSource
import com.bazigar.bulandawaaz.home.fragments.home.HomePostItem
import com.bazigar.bulandawaaz.model.user.UserData
import com.bazigar.bulandawaaz.utils.DataStoreKeys.USER_ID
import com.bazigar.bulandawaaz.utils.NetworkConnectionInterceptor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception
import javax.inject.Inject

class HomeRepository@Inject constructor (
    private val homeService: HomeService,
    private val dataSource: AppDataStore,
    private val network: NetworkConnectionInterceptor,
    private val context: Context
) {
    var userId=0L
    init {
        CoroutineScope(Dispatchers.IO).launch {
          userId= dataSource.readValue(USER_ID).toString().toLong()
        }
    }

    fun getProfilePagingSource()=ProfilePagingSource(homeService,dataSource,network,context)
    fun getHomePagingSource()=HomePagingSource(homeService,network,dataSource,context)

    suspend fun getUserProfile(callback:(Boolean,String,UserData?)->Unit){
        try {
            val userId=dataSource.readValue(USER_ID)?.toLong()!!
            if (!network.checkForInternet()) {
                callback(false, "No Internet connection", null)
                return
            }
          val response = homeService.getUserProfile(userId)
                callback(response.status?.responseCode==200, response.message?:"",response.data)

        }catch (e:Exception){
            callback(false,e.message.toString(),null)
        }

    }

    suspend fun updatePostLikes(item:HomePostItem, callback : (Boolean, String?)->Unit){
        if (network.checkForInternet()) {
            val result = homeService.likePost(userId, item.postId!!.toLong())
            callback(result.status?.responseCode == 200, result.message)
        }else{
            callback(false,"No internet connection")
        }
    }

}