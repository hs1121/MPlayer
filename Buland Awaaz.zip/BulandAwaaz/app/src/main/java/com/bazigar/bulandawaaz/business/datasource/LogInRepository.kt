package com.bazigar.bulandawaaz.business.datasource

import android.util.Log
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.business.datasource.network.login.SignInService
import com.bazigar.bulandawaaz.model.user.UserData
import com.bazigar.bulandawaaz.utils.DataStoreKeys.FIREBASE_TOKEN
import com.bazigar.bulandawaaz.utils.DataStoreKeys.PASSWORD
import com.bazigar.bulandawaaz.utils.DataStoreKeys.USER_ID
import com.bazigar.bulandawaaz.utils.NetworkConnectionInterceptor
import com.bazigar.bulandawaaz.utils.SecurityUtil
import com.bazigar.bulandawaaz.utils.md5
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.lang.Exception
import javax.inject.Inject

class LogInRepository @Inject constructor (
    private val signInService: SignInService,
    private val dataSource: AppDataStore,
    private val networkInterceptor: NetworkConnectionInterceptor
) {
   suspend fun logIn(usernameOrEmail: String, password: String, callback: (Boolean, String?) -> Unit) {
       try {
           if (!networkInterceptor.checkForInternet()){
               callback(false,"No internet connection")
               return
           }
           val response = signInService.loginUser(usernameOrEmail, password)
           if (response.status?.responseCode == 200) {
               response.data?.id?.let { dataSource.setValue(USER_ID, it.toString()) }
               response.data?.firebaseToken?.let { dataSource.setValue(FIREBASE_TOKEN, it) }
                dataSource.setValue(PASSWORD, password)
               withContext(Dispatchers.Main) {
                   callback(true, response.message)
               }
           }
       }catch (e:Exception){
           Log.e("LogInException",e.message.toString())
       }
    }

    suspend fun signUp(
        entity:UserData,
        callback: (Boolean, String?) -> Unit
    ) {

        try {
            if (!networkInterceptor.checkForInternet()){
                callback(false,"No internet connection")
                return
            }
        val fireBaseToken=dataSource.readValue(FIREBASE_TOKEN)
        val deviceName = android.os.Build.MODEL

        val response = signInService.registerUser(
            fullName = entity.fullName!!, emailId = entity.email,
            userName = entity.userName!!, password = entity.userPassword,
            firebaseToken = fireBaseToken, dob = entity.dob, deviceName = deviceName
        , gender = entity.gender, signUpType = entity.signUpType, googleSignInToken = SecurityUtil.encrypt(
                md5(entity.googleSignInToken?:"")),
            profileUrl = entity.profileUrl
        )

            if (response.status?.responseCode == 200) {
                response.data?.id?.let { dataSource.setValue(USER_ID, it.toString()) }
                response.data?.firebaseToken?.let { dataSource.setValue(FIREBASE_TOKEN, it) }
                dataSource.setValue(PASSWORD, entity.userPassword?:"")
                withContext(Dispatchers.Main) {
                    callback(true, response.message)
                }
            }}
        catch (e:Exception){
            Log.e("SignUpException",e.message.toString())
        }
    }

    suspend fun sendOtp(email: String, callback: (Boolean, String?, Long?) -> Unit) {
        try {
            if (!networkInterceptor.checkForInternet()){
                callback(false,"No internet connection",null)
                return
            }
            val response=  signInService.setRegistrationOtp(email)
            withContext(Dispatchers.Main) {
                callback(
                    response.status?.responseCode == 200,
                    response.message,
                    response.data
                )
            }}
        catch (e:Exception){
            Log.e("OtpException",e.message.toString())
        }
    }

    suspend fun verifyOtp(userId: Long, otp: String, callback: (Boolean, String?) -> Unit) {
        try {
            if (!networkInterceptor.checkForInternet()){
                callback(false,"No internet connection")
                return
            }
            val response = signInService.verifyOtp(userId, otp)
            withContext(Dispatchers.Main) {
                callback(
                    response.status?.responseCode == 200,
                    response.message
                )
            }
        } catch (e: Exception) {
            Log.e("OtpException", e.message.toString())
        }
    }

    suspend fun userNameExists(userName: String, callback: (Boolean, String?) -> Unit) {
        try {
            if (!networkInterceptor.checkForInternet()){
                callback(false,"No internet connection")
                return
            }
            val response = signInService.userNameExists(userName)
            withContext(Dispatchers.Main) {
                callback(
                    response.status?.responseCode == 200,
                    response.message
                )
            }
        } catch (e: Exception) {
            Log.e("userNameException", e.message.toString())
        }
    }

    suspend fun updateLocation(userId: Long, state: String, longitude: Double, latitude: Double, city: String, country: String, callback: (Boolean, String?) -> Unit) {
        try {
            if (!networkInterceptor.checkForInternet()){
                callback(false,"No internet connection")
                return
            }
            val response = signInService.updateLocation(userId,state,latitude,longitude,city, country)
            withContext(Dispatchers.Main) {
                callback(
                    response.status?.responseCode == 200,
                    response.message
                )
            }
        } catch (e: Exception) {
            Log.e("OtpException", e.message.toString())
        }
    }
}