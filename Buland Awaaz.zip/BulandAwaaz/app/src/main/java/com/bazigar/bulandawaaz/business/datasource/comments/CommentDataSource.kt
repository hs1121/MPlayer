package com.bazigar.bulandawaaz.business.datasource.comments

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.business.datasource.network.home.CommentService
import com.bazigar.bulandawaaz.model.comment.CommentEntity
import com.bazigar.bulandawaaz.utils.DataStoreKeys.PASSWORD
import com.bazigar.bulandawaaz.utils.DataStoreKeys.USER_ID
import com.bazigar.bulandawaaz.utils.NetworkConnectionInterceptor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Retrofit

class CommentDataSource  constructor(
    private val builder: Retrofit.Builder,
    private val dataStore: AppDataStore,
    private val network: NetworkConnectionInterceptor
) : PagingSource<Int, CommentEntity>() {

    private var postId: Long = 0
     private var service: CommentService?=null
    fun initDataSource(postId:Long){
        this.postId=postId
        service =   builder.build().create(CommentService::class.java)
    }

    private var userId = ""
    private var password=""
    init {
        CoroutineScope(Dispatchers.IO).launch {
            userId = dataStore.readValue(USER_ID).toString()
            password = dataStore.readValue(PASSWORD).toString()
        }
    }
    override fun getRefreshKey(state: PagingState<Int, CommentEntity>): Int? {
        return state.anchorPosition
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, CommentEntity> {
     //   val position = params.key ?: 0
        return try {
            if (!network.checkForInternet()) {
//
                LoadResult.Error(Throwable("No internet"))
            }else {
                val response = service?.fetchComments(postId, userId)
                val domainResponse = response?.toCommentEntity()?: emptyList()
            //    dao.insertComments(domainResponse)
                LoadResult.Page(
                    data = domainResponse,
                    prevKey = null,
                    nextKey = null
                )
            }
        } catch (e: Exception) {
            LoadResult.Error(e)
        }


    }

    suspend fun addComment(comment: String, callback : (Boolean, String?)->Unit){
        if (network.checkForInternet()) {
            comment.apply {
                val result = service?.addComment(userId, postId.toInt(), comment)
                callback(result?.status?.responseCode == 200||result?.status?.responseCode == 201, result?.message)
            }
        }else {
            callback(false, "No internet connection")
        }

    }


    suspend fun likeComment(item: CommentEntity, callback : (Boolean, String?)->Unit){
        if (network.checkForInternet()) {
            val result = service?.likeComment(userId, item.commentId)
            callback(result?.status?.responseCode == 200, result?.message)
        }else {
            callback(false, "No internet connection")
        }
    }

    enum class CommentType {
        POST_COMMENT,VIBE_COMMENT,MPTV_COMMENT
    }

}