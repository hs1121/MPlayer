package com.bazigar.bulandawaaz.business.datasource.comments

import android.content.Context
import com.bazigar.bulandawaaz.business.datasource.comments.CommentDataSource
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.utils.NetworkConnectionInterceptor
import dagger.hilt.android.qualifiers.ApplicationContext
import retrofit2.Retrofit
import javax.inject.Inject

class CommentDataSourceFactory @Inject constructor(
    private val builder: Retrofit.Builder,
    private val network: NetworkConnectionInterceptor,
    private val dataStore: AppDataStore,
    @ApplicationContext private val context: Context,
) {
    fun dataSourceInstance()= CommentDataSource(builder,dataStore,network)
}