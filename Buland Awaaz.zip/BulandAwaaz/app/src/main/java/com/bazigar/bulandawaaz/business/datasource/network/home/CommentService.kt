package com.bazigar.bulandawaaz.business.datasource.network.home

import com.bazigar.bulandawaaz.model.comment.CommentResponse
import com.bazigar.bulandawaaz.utils.Constants.USER_END_POINT

import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
//const val USER_END_POINT="my-post-api/index.php/api/User/"
interface CommentService {

    @FormUrlEncoded
    @POST(USER_END_POINT + "getPostComments")
     suspend fun fetchComments(
        @Field("postId") postId: Long,
        @Field("userId") userId: String
    ):CommentResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "add_post_comment")
     suspend fun addComment(
        @Field("userId") userId: String,
        @Field("postId") postId: Int,
        @Field("comment") comment:String
    ): CommentResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "add_post_comment_reply")
     suspend fun addCommentReply(
        @Field("userId") userId: String,
        @Field("postId") postId: Int,
        @Field("reply") reply:String
    ): CommentResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "delete_post_comment")
     suspend fun deleteComment(
        @Field("userId") userId: String,
        @Field("commentId") commentId: Long
    ): CommentResponse
    @FormUrlEncoded
    @POST(USER_END_POINT + "add_post_comment_reply")
     suspend fun deleteCommentReply(
        @Field("userId") userId: String,
        @Field("replyId") replyId: Long,
    ): CommentResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "like_post_comment")
     suspend fun likeComment(
        @Field("userId") userId: String,
        @Field("commentId") commentId: Long
    ): CommentResponse





}