package com.bazigar.bulandawaaz.business.datasource.network.home

import com.bazigar.bulandawaaz.home.fragments.home.HomePostResponse
import com.bazigar.bulandawaaz.model.user.UserPostResponse
import com.bazigar.bulandawaaz.model.user.UserResponse
import com.bazigar.bulandawaaz.utils.Constants.USER_END_POINT
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface HomeService {

    @FormUrlEncoded
    @POST(USER_END_POINT + "get_user_profile")
    suspend fun getUserProfile(
        @Field("userId") userId: Long
    ): UserResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "fetchUserUploadedPosts")
    suspend fun fetchUserUploadedPost(
        @Field("userId") userId: Long,
        @Field("pageNo") pageNo:Int
    ): UserPostResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "fetch_posts")
    suspend fun fetchHomePost(
        @Field("userId") userId: Long,
        @Field("pageNo") pageNo:Int
    ): HomePostResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "like_post")
    suspend fun likePost(
        @Field("userId") userId: Long,
        @Field("postId") postId:Long,
    ): HomePostResponse



}