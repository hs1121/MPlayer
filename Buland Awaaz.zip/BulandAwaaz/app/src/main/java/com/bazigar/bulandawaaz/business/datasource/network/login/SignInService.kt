package com.bazigar.bulandawaaz.business.datasource.network.login

import com.bazigar.bulandawaaz.model.user.RegistrationOtpResponse
import com.bazigar.bulandawaaz.model.user.UserResponse
import com.bazigar.bulandawaaz.utils.Constants.USER_END_POINT
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface SignInService {

    @FormUrlEncoded
    @POST(USER_END_POINT + "login_user")
    suspend fun loginUser(
        @Field("nameEmailOrPhone") emailId: String,
        @Field("password") password: String
    ): UserResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "register_user")
    suspend fun registerUser(
        @Field("email") emailId: String?,
        @Field("userName") userName: String,
        @Field("fullName") fullName: String,
        @Field("password") password: String?,
        @Field("deviceName") deviceName: String?,
        @Field("dob") dob: String?,
        @Field("gender") gender: String?,
        @Field("firebaseToken") firebaseToken: String?,
        @Field("signUpType") signUpType: String?,
        @Field("googleSignInToken") googleSignInToken: String?,
        @Field("profileUrl") profileUrl: String?
    ): UserResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "updateLocation")
    suspend fun updateLocation(
        @Field("userId") userId: Long,
        @Field("state") state: String,
        @Field("latitude") latitude: Double,
        @Field("longitude") longitude: Double,
        @Field("city") city: String,
        @Field("country") country: String
    ): UserResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "sendOTPToEmailOrPhone")
    suspend fun setRegistrationOtp(
        @Field("emailOrPhone") emailId: String
    ): RegistrationOtpResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "verify_registration_otp")
    suspend fun verifyOtp(
        @Field("validationId") validationId: Long,
        @Field("otp") otp: String
    ): RegistrationOtpResponse

    @FormUrlEncoded
    @POST(USER_END_POINT + "username_exists")
    suspend fun userNameExists(
        @Field("userName") userName: String
    ): RegistrationOtpResponse
}