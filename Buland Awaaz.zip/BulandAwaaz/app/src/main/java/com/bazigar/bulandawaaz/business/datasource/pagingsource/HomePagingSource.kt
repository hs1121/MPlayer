package com.bazigar.bulandawaaz.business.datasource.pagingsource

import android.content.Context
import android.content.Intent
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.bazigar.bulandawaaz.business.caching.PreCatchingService
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.business.datasource.network.home.HomeService
import com.bazigar.bulandawaaz.home.fragments.home.HomePostItem
import com.bazigar.bulandawaaz.utils.Constants.VIDEO_LIST
import com.bazigar.bulandawaaz.utils.DataStoreKeys
import com.bazigar.bulandawaaz.utils.NetworkConnectionInterceptor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HomePagingSource (
    private val service: HomeService,
    private val network: NetworkConnectionInterceptor,
    private val dataStore: AppDataStore,
    private val context: Context

) : PagingSource<Int, HomePostItem>() {


    private var userId = ""
    private var password=""

    init {
        CoroutineScope(Dispatchers.IO).launch {
            userId = dataStore.readValue(DataStoreKeys.USER_ID).toString()
            password = dataStore.readValue(DataStoreKeys.PASSWORD).toString()
        }
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, HomePostItem> {


        val position = params.key ?: 0


        return try {
            if (!network.checkForInternet()) {
//                val localData = postDao.fetchPosts()
//                LoadResult.Page(
//                    data = localData!!,
//                    prevKey = null,
//                    nextKey = null
//                )
                LoadResult.Error(Throwable("No Internet"))
            }else {
                val response = service.fetchHomePost(userId.toLong(), position)
                val domainResponse = response.data?.objects

//                postDao.insertPosts(domainResponse)
                val videoList = arrayListOf<String>()
                domainResponse?.forEach {
                    // if (it.isVideoContent())
                    it.postUrl?.let { it1 -> videoList.add(it1) }
                }
                startPreLoadingService(videoList)

                LoadResult.Page(
                    data = domainResponse!!,
                    prevKey = if (position != 0) position - 1 else null,
                    nextKey = if (position < response.data.totalPages!!) position + 1 else null,
                )
            }
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, HomePostItem>): Int? {
        return null
    }

    private fun startPreLoadingService(videoList:ArrayList<String>) {
        val preloadingServiceIntent = Intent(context, PreCatchingService::class.java)
        preloadingServiceIntent.putStringArrayListExtra(VIDEO_LIST, videoList)
        context?.startService(preloadingServiceIntent)
    }

}
