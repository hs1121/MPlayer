package com.bazigar.bulandawaaz.business.datasource.pagingsource

import android.content.Context
import android.content.Intent
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.bazigar.bulandawaaz.business.caching.PreCatchingService
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.business.datasource.network.home.HomeService
import com.bazigar.bulandawaaz.model.user.UserPost
import com.bazigar.bulandawaaz.utils.Constants
import com.bazigar.bulandawaaz.utils.DataStoreKeys.USER_ID
import com.bazigar.bulandawaaz.utils.NetworkConnectionInterceptor


class ProfilePagingSource(
    private val homeService: HomeService,
    private val dataSource: AppDataStore,
    private val network: NetworkConnectionInterceptor,
    private val context: Context
)  : PagingSource<Int, UserPost>() {
    private var userId: Long = 0
    override fun getRefreshKey(state: PagingState<Int, UserPost>): Int? {
        return null
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, UserPost> {
        return try {
            val position = params.key ?: 0
            userId=dataSource.readValue(USER_ID)?.toLong()!!
            if (!network.checkForInternet()) {
//                val localData = postDao.fetchPosts()
//                LoadResult.Page(
//                    data = localData!!,
//                    prevKey = null,
//                    nextKey = null
//                )
                LoadResult.Error(Throwable("No internet connection"))
            }else {
                val response = homeService.fetchUserUploadedPost(userId, position)
                val domainResponse = response.data.objects

                val videoList = arrayListOf<String>()
                domainResponse.forEach {
                    // if (it.isVideoContent())
                    it.postUrl?.let { it1 -> videoList.add(it1) }
                }
                startPreLoadingService(videoList)

                LoadResult.Page(
                    data = domainResponse,
                    prevKey = if (position != 0) position - 1 else null,
                    nextKey = if (position < response.data.totalPages) position + 1 else null,
                )
            }
        } catch (e: Exception) {
            LoadResult.Error(e)
        }

    }
    private fun startPreLoadingService(videoList:ArrayList<String>) {
        val preloadingServiceIntent = Intent(context, PreCatchingService::class.java)
        preloadingServiceIntent.putStringArrayListExtra(Constants.VIDEO_LIST, videoList)
        context?.startService(preloadingServiceIntent)
    }

}