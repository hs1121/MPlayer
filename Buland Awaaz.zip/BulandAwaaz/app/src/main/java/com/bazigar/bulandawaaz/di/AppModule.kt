package com.bazigar.bulandawaaz.di

import android.app.Application
import android.content.Context
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.business.datasource.HomeRepository
import com.bazigar.bulandawaaz.business.datasource.LogInRepository
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStoreManager
import com.bazigar.bulandawaaz.business.datasource.network.home.HomeService
import com.bazigar.bulandawaaz.business.datasource.network.login.SignInService
import com.bazigar.bulandawaaz.utils.Constants.BASE_URL
import com.bazigar.bulandawaaz.utils.NetworkConnectionInterceptor
import com.bumptech.glide.Glide
import com.bumptech.glide.RequestManager
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.google.gson.Gson
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Singleton
    @Provides
    fun provideGson()=Gson()

    @Singleton
    @Provides
    fun provideHttpClient(): OkHttpClient {
        val httpLoggingInterceptor = HttpLoggingInterceptor()
        httpLoggingInterceptor.level = HttpLoggingInterceptor.Level.BODY
        val builder = OkHttpClient.Builder().addInterceptor(httpLoggingInterceptor)
        builder.connectTimeout(1, TimeUnit.MINUTES)
        builder.readTimeout(1, TimeUnit.MINUTES)
        //.addInterceptor(networkConnectionInterceptor)
        return builder.build()
    }

    @Singleton
    @Provides
    fun provideRetrofitBuilder(gsonBuilder: Gson, client: OkHttpClient): Retrofit.Builder {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(gsonBuilder))
    }
    @Singleton
    @Provides
    fun provideSignInService(builder:Retrofit.Builder)= builder.build().create(SignInService::class.java)

    @Singleton
    @Provides
    fun provideHomeService(builder:Retrofit.Builder)= builder.build().create(HomeService::class.java)


    @Singleton
    @Provides
    fun provideRequestOptions(): RequestOptions {
        return RequestOptions
            .placeholderOf(R.drawable.place_holder)
            .error(R.drawable.place_holder)
            .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
    }

    @Singleton
    @Provides
    fun provideDataStoreManager(
        application: Application
    ): AppDataStore {
        return AppDataStoreManager(application)
    }

    @Singleton
    @Provides
    fun provideGlideInstance(
        application: Application,
        requestOptions: RequestOptions
    ): RequestManager {

        return Glide.with(application)
            .setDefaultRequestOptions(requestOptions)


    }
    @Singleton
    @Provides
    fun provideLogInRepository(
        signInService: SignInService,
        dataStore: AppDataStore,
    networkConnectionInterceptor: NetworkConnectionInterceptor
    )= LogInRepository(signInService,dataStore,networkConnectionInterceptor)

    @Singleton
    @Provides
    fun provideHomeRepository(
        homeService: HomeService,
        dataStore: AppDataStore,
        networkConnectionInterceptor: NetworkConnectionInterceptor,
        @ApplicationContext context: Context
    )= HomeRepository(homeService,dataStore,networkConnectionInterceptor,context)


    @Singleton
    @Provides
    fun provideNetworkInterceptor(
        @ApplicationContext context:Context
    )= NetworkConnectionInterceptor(context)

}