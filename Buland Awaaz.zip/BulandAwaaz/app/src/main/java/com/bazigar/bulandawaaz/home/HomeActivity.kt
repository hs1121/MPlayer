package com.bazigar.bulandawaaz.home

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.ActivityHomeBinding
import com.bazigar.bulandawaaz.home.fragments.post.PostFragment
import com.bazigar.bulandawaaz.utils.Constants.REQUEST_CODE_CAMERA
import com.bazigar.bulandawaaz.utils.Constants.REQUIRED_PERMISSIONS
import com.bazigar.bulandawaaz.utils.PostTypeDialog
import com.google.android.material.navigation.NavigationBarView
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class HomeActivity : AppCompatActivity() {
    private lateinit var navController: NavController
    private lateinit var homeViewModel: HomeViewModel
     lateinit var binding:ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        homeViewModel = HomeViewModel.getInstance(this)!!
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment
        navController = navHostFragment.navController
        binding.bottomNavigationView.setupWithNavController(navController)
        //  setupActionBarWithNavController(navController)
        val postItem=findViewById<View>(R.id.postFragment)
        postItem.setOnClickListener {
            val fragmentManager: FragmentManager = supportFragmentManager
                        val fragmentTransaction: FragmentTransaction =
                            fragmentManager.beginTransaction()
                        fragmentTransaction.replace(R.id.fragmentContainerView,PostFragment() )
                        fragmentTransaction.addToBackStack(null)
                        fragmentTransaction.commit()
        }

//        binding.bottomNavigationView.setOnItemSelectedListener {
//            if (it.itemId == R.id.postFragment) {
//                PostTypeDialog {
//                    if (it== R.id.media_post){
//                        val fragmentManager: FragmentManager = supportFragmentManager
//                        val fragmentTransaction: FragmentTransaction =
//                            fragmentManager.beginTransaction()
//                        fragmentTransaction.replace(R.id.fragmentContainerView,PostFragment() )
//                        fragmentTransaction.addToBackStack(null)
//                        fragmentTransaction.commit()
//                    }
//                }.show(supportFragmentManager, "Media Select Response")
//                  return@setOnItemSelectedListener  true
//            }
//            false
//        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || return super.onSupportNavigateUp()


    }


    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults:
        IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_CAMERA) {
            if (allPermissionsGranted {}) {
                cameraPermissionCallback?.let { it() }
            } else {
                Toast.makeText(this,
                    "Permissions not granted by the user.",
                    Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
    private var cameraPermissionCallback:( () -> Unit)?=null

    fun allPermissionsGranted(cameraPermissionCallback: () -> Unit) = REQUIRED_PERMISSIONS.all {
        this.cameraPermissionCallback=cameraPermissionCallback
        ContextCompat.checkSelfPermission(
            baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }


}