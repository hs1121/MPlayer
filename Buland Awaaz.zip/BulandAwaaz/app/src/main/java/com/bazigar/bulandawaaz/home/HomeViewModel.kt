package com.bazigar.bulandawaaz.home

import androidx.lifecycle.*
import androidx.paging.*
import com.bazigar.bulandawaaz.business.datasource.HomeRepository
import com.bazigar.bulandawaaz.home.fragments.home.HomePostItem
import com.bazigar.bulandawaaz.model.user.UserData
import com.bazigar.bulandawaaz.model.user.UserPost
import com.bumptech.glide.RequestManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val homeRepository: HomeRepository
) :
    ViewModel() {
    
    companion object{
        private var homeViewModel:HomeViewModel?=null
        fun getInstance(owner:ViewModelStoreOwner?=null)=
            if (homeViewModel==null) {
                homeViewModel = ViewModelProvider(owner!!).get(HomeViewModel::class.java)
                homeViewModel
            }else
                homeViewModel

    }

    private val _profileGalleryState = Pager(
        config = PagingConfig(20),
    ) {
        homeRepository.getProfilePagingSource()
    }.liveData.cachedIn(viewModelScope) as MutableLiveData

    val profileGalleryState
    get() = _profileGalleryState

    private val _homePostState = Pager(
        config = PagingConfig(20),
    ) {
        homeRepository.getHomePagingSource()
    }.liveData.cachedIn(viewModelScope) as MutableLiveData

    val homePostState
        get() = _homePostState



    fun getProfileDetails(callback:(Boolean, String, UserData?)->Unit){
        viewModelScope.launch {
            homeRepository.getUserProfile(callback)
        }
    }

    fun updateLikes(item:HomePostItem, callback: (Boolean,String?)->Unit){
        viewModelScope.launch {
            homeRepository.updatePostLikes(item) { isSuccess, message->
                callback(isSuccess,message)
                if (isSuccess) {
                    //updatePostDatabase(item)
                }
            }
        }
    }


}