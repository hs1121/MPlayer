package com.bazigar.mypost.presentation.comments

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.bazigar.bulandawaaz.home.comments.CommentsViewModel
import com.bazigar.bulandawaaz.business.datasource.comments.CommentDataSourceFactory


class CommentViewModelFactory(
    private val commentDataSourceFactory: CommentDataSourceFactory,
    private val postId: Long
) : ViewModelProvider.Factory {

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return CommentsViewModel(commentDataSourceFactory= commentDataSourceFactory,postId = postId) as T
    }

}