package com.bazigar.mypost.presentation.comments

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color.red
import android.view.LayoutInflater
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.core.widget.ImageViewCompat
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.CommentItemLayoutBinding
import com.bazigar.bulandawaaz.model.comment.CommentEntity
import com.bumptech.glide.RequestManager
import com.google.android.exoplayer2.ExoPlayer

class CommentsAdapter(
    private val glide:RequestManager,
    private val context: Context
):  PagingDataAdapter<CommentEntity, CommentsAdapter.CommentViewHolder>(
    diffUtil
)  {
    private lateinit var listener: CommentListeners


    companion object {
        val diffUtil = object : DiffUtil.ItemCallback<CommentEntity>() {
            override fun areItemsTheSame(
                oldItem: CommentEntity,
                newItem: CommentEntity
            ): Boolean = oldItem.postId == newItem.postId

            override fun areContentsTheSame(
                oldItem: CommentEntity,
                newItem: CommentEntity
            ): Boolean = oldItem == newItem

        }
    }

    override fun onBindViewHolder(holder: CommentViewHolder, position: Int) {
        getItem(position)?.apply {
            holder.binding.apply {
                commentUserComment.text=comment
                commentLikesCount.text="$likeCount like"

                if (replyCount!!>0){
                    commentMoreRepliesContainer.visibility=VISIBLE
                    commentMoreReplies.text="------- view $replyCount replies"
//                    commentMoreRepliesRecyclerView.layoutManager=LinearLayoutManager(this.root.context)
//                    commentMoreRepliesRecyclerView.adapter=CommentsAdapter(glide,this.root.context) // todo not yet implemented in backend
                }
                commentUserLikeButton.setOnClickListener {
                    listener.onLikeClicked(getItem(position)!!,holder)
                }
                commentProfilePhoto.setOnClickListener {
                    listener.onProfileClicked(getItem(position)!!)
                }

            }
            holder.updateLike(this)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CommentViewHolder {
        val view=CommentItemLayoutBinding.inflate(LayoutInflater.from(parent.context))
        return CommentViewHolder(view)
    }

    class CommentViewHolder(val binding: CommentItemLayoutBinding): RecyclerView.ViewHolder(binding.root) {
        private val context=binding.root.context
        fun updateLike(item: CommentEntity?) {
            binding.apply {
                item?.let { item->
                    if(item.likedOrNot) {
                        ImageViewCompat.setImageTintList(
                            commentUserLikeButton,
                            ColorStateList.valueOf(context.resources.getColor(R.color.primary))
                        )
                    }
                    else{
                        ImageViewCompat.setImageTintList(
                            commentUserLikeButton,
                            ColorStateList.valueOf(context.resources.getColor(R.color.black))
                        )
                    }
                    commentLikesCount.text="${item.likeCount} likes"
                }
            }

        }

    }

    fun setCommentListeners(listener:CommentListeners){
        this.listener=listener
    }

    interface CommentListeners{
        fun onLikeClicked(item : CommentEntity,view:CommentViewHolder)=Unit
        fun onProfileClicked(item:CommentEntity)=Unit
        fun onLoadRepliesClicked(item:CommentEntity)=Unit
    }

}