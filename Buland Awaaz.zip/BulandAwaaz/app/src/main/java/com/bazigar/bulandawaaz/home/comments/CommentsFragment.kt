package com.bazigar.bulandawaaz.home.comments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import androidx.paging.PagingData
import androidx.recyclerview.widget.LinearLayoutManager
import com.bazigar.bulandawaaz.databinding.FragmentCommentsBinding
import com.bazigar.bulandawaaz.model.comment.CommentEntity
import com.bazigar.bulandawaaz.business.datasource.comments.CommentDataSourceFactory
import com.bazigar.mypost.presentation.comments.CommentViewModelFactory
import com.bazigar.mypost.presentation.comments.CommentsAdapter
import com.bumptech.glide.RequestManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class CommentsFragment(
//    private val postId:Long,
//    private  val commentType: CommentDataSource.CommentType
) : Fragment() {
    private val args:CommentsFragmentArgs by navArgs()
private lateinit var binding: FragmentCommentsBinding

    private lateinit var commentsAdapter: CommentsAdapter
    @Inject
    lateinit var glide:RequestManager
    @Inject
    lateinit var commentDataSourceFactory: CommentDataSourceFactory
    private val commentViewModel: CommentsViewModel by
    viewModels{ CommentViewModelFactory(commentDataSourceFactory,args.postId) }
 //   viewModels{CommentViewModelFactory(commentDataSource,postId,commentType)}




    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentCommentsBinding.inflate(inflater)
        binding.recyclerView.layoutManager=LinearLayoutManager(requireContext())
                commentsAdapter= CommentsAdapter(glide,requireContext())
        binding.recyclerView.adapter=commentsAdapter
        commentViewModel.commentState.observe(viewLifecycleOwner){ data->
                commentsAdapter.submitData(viewLifecycleOwner.lifecycle, data?: PagingData.empty())

        }
        setupListeners()


        return binding.root
    }

    private fun setupListeners() {
        commentsAdapter.setCommentListeners(object : CommentsAdapter.CommentListeners {
            override fun onLikeClicked(
                item: CommentEntity,
                view: CommentsAdapter.CommentViewHolder
            ) {
                val likeSnapshot = commentsAdapter.snapshot().firstOrNull { snapshotItem ->
                    snapshotItem?.postId == item.postId
                }
                likeSnapshot?.apply {
                    likedOrNot = !likedOrNot!!
                    if (likedOrNot)
                        likeCount++
                    else
                        likeCount--
                }
                view.updateLike(likeSnapshot)
                commentViewModel.likeComment(item){ isSuccess,message->
                    if (!isSuccess) {
                        likeSnapshot.apply {
                            likeSnapshot?.apply {
                                likedOrNot = !likedOrNot
                                if (likedOrNot)
                                    likeCount++
                                else
                                    likeCount--
                            }

                        }
                        view.updateLike(likeSnapshot)
                        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                    }


                }

            }


        })
        binding.commentPostBtn.setOnClickListener {
            val comment=binding.commentInputText.text.toString()
            if (comment.isNotBlank()){
                commentViewModel.addComment(comment){success,message->
                    run {
                        if (success) {
                            commentsAdapter.refresh()
                            binding.commentInputText.setText("")
                        }
                        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                    }
                }

            }
        }
    }



}