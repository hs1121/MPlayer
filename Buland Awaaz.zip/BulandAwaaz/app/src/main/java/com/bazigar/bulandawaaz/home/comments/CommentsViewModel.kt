package com.bazigar.bulandawaaz.home.comments

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.*
import com.bazigar.bulandawaaz.model.comment.CommentEntity
import com.bazigar.bulandawaaz.business.datasource.comments.CommentDataSource
import com.bazigar.bulandawaaz.business.datasource.comments.CommentDataSourceFactory
import kotlinx.coroutines.launch

class CommentsViewModel  constructor (
    private val commentDataSourceFactory: CommentDataSourceFactory,
    private val postId:Long

) :ViewModel() {
    private var commentDataSource: CommentDataSource?=null

    private  val _commentState:  MutableLiveData<PagingData<CommentEntity>>
    val commentState  get()  = _commentState as LiveData<PagingData<CommentEntity>>

    init {
       _commentState= Pager(
            config = PagingConfig(20),
        ) {
          commentDataSourceFactory.dataSourceInstance().also {
              it.initDataSource(postId)
              commentDataSource=it
          }
        }.liveData.cachedIn(viewModelScope) as MutableLiveData
    }
    fun likeComment(item: CommentEntity,callback : (Boolean, String?)->Unit) {
        viewModelScope.launch {
            commentDataSource?.likeComment(item){success,message->
                callback(success,message)
            }
        }
    }

    fun addComment(item: String,callback : (Boolean, String?)->Unit) {
        viewModelScope.launch {
            commentDataSource?.addComment(item){success,message->
                callback(success,message)
            }
        }
    }

}