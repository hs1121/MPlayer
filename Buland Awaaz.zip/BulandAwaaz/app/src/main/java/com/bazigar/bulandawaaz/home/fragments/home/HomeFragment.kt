package com.bazigar.bulandawaaz.home.fragments.home

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.FragmentHomeBinding
import com.bazigar.bulandawaaz.home.HomeViewModel
import com.bumptech.glide.RequestManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class HomeFragment : Fragment() {
    private lateinit var binding:FragmentHomeBinding
    private val homeViewModel:HomeViewModel by viewModels()
    private lateinit var newsListAdapter: NewsListAdapter
    @Inject
    lateinit var requestManager: RequestManager
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentHomeBinding.inflate(layoutInflater)
        newsListAdapter= NewsListAdapter(requestManager)
        binding.recyclerView.apply {
            layoutManager=LinearLayoutManager(requireContext())
            adapter=newsListAdapter
        }


        homeViewModel.homePostState.observe(viewLifecycleOwner){
            newsListAdapter.submitData(viewLifecycleOwner.lifecycle,it)
        }

        setUpListeners()

        return binding.root
    }

    private fun setUpListeners() {


//        binding.postScrollView.viewTreeObserver.addOnScrollChangedListener(OnScrollChangedListener {
//            if (binding.postScrollView.scrollY == 0) {
//                binding.appBar.translationZ=0f
//            } else {
//                binding.appBar.translationZ=(8 * Resources.getSystem().displayMetrics.density);
//            }
//        })

        newsListAdapter.setPostListeners(object : NewsListAdapter.PostListeners {
            override fun onFollowButtonClicked(item: HomePostItem) {
                TODO("Not yet implemented")
            }

            override fun onLikeDislikeClicked(item: HomePostItem,view:NewsListAdapter.PostViewHolder) {

                val likeSnapshot = newsListAdapter.snapshot().firstOrNull { snapshotItem ->
                    snapshotItem?.postId == item.postId
                }
                val position= newsListAdapter.snapshot().indexOf(likeSnapshot)
                likeSnapshot?.apply {
                    likedOrNot = !likedOrNot!!
                    if (likedOrNot==true)
                        likeCount++
                    else
                        likeCount--
                }
                view.updateLike(likeSnapshot)
                homeViewModel.updateLikes(item){ isSuccess,message->
                    if (!isSuccess) {
                        likeSnapshot.apply {
                            likeSnapshot?.apply {
                                likedOrNot = !likedOrNot!!
                                if (likedOrNot == true)
                                    likeCount++
                                else
                                    likeCount--
                            }

                        }
                        view.updateLike(likeSnapshot)
                      //  Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                    }


                }

            }

            override fun onCommentClicked(item: HomePostItem) {
                val action = HomeFragmentDirections.actionHomeFragmentToCommentsFragment(item.postId!!.toLong())
                findNavController().navigate(action)
                newsListAdapter.refresh()
            }

            override fun onProfileClicked(item: HomePostItem) {
                TODO("Not yet implemented")
            }

            override fun onMoreButtonClicked(item: HomePostItem) {
                TODO("Not yet implemented")
            }

        })
    }


    override fun onResume() {
        super.onResume()
        newsListAdapter.playCurrentPlayer()
        newsListAdapter.refresh()
    }
    override fun onStop() {
        super.onStop()
        newsListAdapter.pauseCurrentPlayer()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        newsListAdapter.releasePlayers()
    }





}