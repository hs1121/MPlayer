package com.bazigar.bulandawaaz.home.fragments.home

import android.content.Context
import android.graphics.Point
import android.util.AttributeSet
import android.util.Log
import android.view.Display
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bazigar.bulandawaaz.R
import com.google.android.exoplayer2.ExoPlayer

class HomePostRecyclerView : RecyclerView {

    constructor(context: Context) : super(context)

    constructor(context: Context, attributeSet: AttributeSet) : super(context, attributeSet)

    private val lister: MutableList<Int> = mutableListOf()
    private var videoSurfaceDefaultHeight: Int = 0
    private var screenDefaultHeight: Int = 0
    private lateinit var videoUrls: List<HomePostItem>
    private var currentPlayer: ExoPlayer? = null

    private enum class VolumeState { ON, OFF }

    private var volumeState = VolumeState.OFF

    init {
        val display: Display =
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
        val point = Point()
        display.getSize(point)
        videoSurfaceDefaultHeight = point.x
        screenDefaultHeight = point.y
    }

    override fun onChildAttachedToWindow(child: View) {
        super.onChildAttachedToWindow(child)
        Log.d("RecyclerView", "Child view Attached To Window")
        val item = child.tag as NewsListAdapter.PostViewHolder
        if (item.currentData?.type?.uppercase() == "VIDEO") {
            item.initPlayer(item.hlsUrl!!)
            lister.add(item.absoluteAdapterPosition)
        }
        item.postVideo.let { playerView ->
            playerView?.setOnClickListener {
                item.exoPlayer?.let {
                    NewsListAdapter.currentPlayerInstance=it
                    it.volume = if (it.volume == 0f) {
                        volumeState = VolumeState.ON
                        item.volumeImage.setImageResource(R.drawable.ic_volume_on)
                        1f
                    } else {
                        volumeState = VolumeState.OFF
                        item.volumeImage.setImageResource(R.drawable.ic_volume_off)
                        0f
                    }
                }
            }
        }
    }

    override fun onChildDetachedFromWindow(child: View) {
        super.onChildDetachedFromWindow(child)
        val item = child.tag as NewsListAdapter.PostViewHolder
        lister.remove(item.absoluteAdapterPosition)
        item.releasePlayer()
        NewsListAdapter.currentPlayerInstance=null
        Log.d("RecyclerView", "Child Detached From Window")
    }

    override fun onScrollStateChanged(state: Int) {
        super.onScrollStateChanged(state)
        Log.d("RecyclerView", "Scroll state changed")
        if (state == SCROLL_STATE_IDLE) {
            Log.d("RecyclerView", "lister is $lister")
            if (lister.size != 0) {
                val itemHeights: List<Int> = lister.map {
                    getVisibleItemHeight(it)
                }
                Log.d("RecyclerView", "The height array is $itemHeights")
                val maxHeight = itemHeights.maxOrNull()!!
                Log.d("RecyclerView", "The max height is $maxHeight")
                val maxHeightPosition = itemHeights.indexOf(maxHeight)
                val gold = lister[maxHeightPosition]
                val superItem =
                    findViewHolderForAdapterPosition(gold) as NewsListAdapter.PostViewHolder
                currentPlayer = superItem.exoPlayer
                currentPlayer?.volume = setVolume(superItem.volumeImage)
                superItem.startPlaying()
                superItem.volumeController.visibility = View.VISIBLE
                superItem.volumeController.setOnClickListener {
                    toggleVolume(superItem.volumeImage)
                }
                for (i in lister) {
                    if (i != gold) {
                        val item =
                            findViewHolderForAdapterPosition(i) as NewsListAdapter.PostViewHolder
//                    val eplayer = SimpleExoPlayer.Builder(item.itemView.context)
//                        .build()
//                        .apply {
//                            item.playerView.player = this
//                            setMediaItem(MediaItem.fromUri(videoUrls[i]))
//                            playWhenReady = false
//                        }
                        item.pausePlaying()
                        item.volumeController.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun setVolume(volumeImage: ImageView): Float {
        return if (volumeState == VolumeState.OFF) {
            volumeImage.setImageResource(R.drawable.ic_volume_off)
            0f
        } else {
            volumeImage.setImageResource(R.drawable.ic_volume_on)
            1f
        }
    }

    private fun toggleVolume(volumeImage: ImageView) {
        if (volumeState == VolumeState.OFF) {
            volumeState = VolumeState.ON
            currentPlayer?.volume = 1f
            volumeImage.setImageResource(R.drawable.ic_volume_on)
        } else {
            volumeState = VolumeState.OFF
            currentPlayer?.volume = 0f
            volumeImage.setImageResource(R.drawable.ic_volume_off)
        }
    }

    private fun getVisibleItemHeight(position: Int): Int {

        val child =
            findViewHolderForAdapterPosition(position) as NewsListAdapter.PostViewHolder
        val item = child.itemView
        val location = IntArray(2)
        val l2 = IntArray(2)
        item.getLocationInWindow(location)
        item.getLocationOnScreen(l2)
        Log.d("RecyclerView", "Location window is ${location.toList()}")
        Log.d("RecyclerView", "Location screen is ${l2.toList()}")
        return if (location[1] < 0) {
            location[1] + videoSurfaceDefaultHeight
        } else {
            screenDefaultHeight - location[1]
        }
    }


    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        Log.d("RecyclerView", "Window focus changed")
        if (hasWindowFocus) {
            currentPlayer?.play()
        } else {
            currentPlayer?.pause()
        }
    }


    fun setUpVideoUrls(urls: List<HomePostItem>) {
        this.videoUrls = urls
    }
}