package com.bazigar.bulandawaaz.home.fragments.home

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.AnimatedVectorDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.ImageViewCompat
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.business.caching.CacheDataSourceFactory
import com.bazigar.bulandawaaz.databinding.FragmentHomeItemCardBinding
import com.bazigar.bulandawaaz.utils.DoubleClickListener

import com.bumptech.glide.RequestManager
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.google.android.exoplayer2.*
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.ui.PlayerView
import kotlinx.coroutines.*


class NewsListAdapter(
    private val glide:RequestManager) :
    PagingDataAdapter<HomePostItem, NewsListAdapter.PostViewHolder>(diffUtil) {

    private lateinit var listener: PostListeners
    private lateinit var context: Context
    private lateinit var cacheDataSourceFactory: CacheDataSourceFactory
    private lateinit var progressiveMediaSource: ProgressiveMediaSource.Factory
    private val exoPlayerInstances:HashMap<Long,ExoPlayer> = hashMapOf()
    private lateinit var job:CoroutineScope

    private lateinit var mediaSourceFactory: DefaultMediaSourceFactory


    private fun initialize(){

        cacheDataSourceFactory =  CacheDataSourceFactory(context, 100 * 1024 * 1024, 5 * 1024 * 1024)
        mediaSourceFactory=DefaultMediaSourceFactory(context)
        progressiveMediaSource = ProgressiveMediaSource.Factory(cacheDataSourceFactory)
    }

    companion object {
        var currentPlayerInstance:ExoPlayer?=null
        val diffUtil = object : DiffUtil.ItemCallback<HomePostItem>() {
            override fun areItemsTheSame(
                oldItem: HomePostItem,
                newItem: HomePostItem
            ): Boolean = oldItem.postId == newItem.postId

            override fun areContentsTheSame(
                oldItem: HomePostItem,
                newItem: HomePostItem
            ): Boolean = oldItem == newItem

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val binding =
            FragmentHomeItemCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        this.context=parent.context
        job= CoroutineScope(Dispatchers.Main)
        initialize()
        return PostViewHolder(binding)
    }
    @OptIn(DelicateCoroutinesApi::class)
    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        getItem(position)?.let {item-> holder.bind(item)
            holder.postItemBinding.apply {
                followButton.setOnClickListener{
                    listener.onFollowButtonClicked(item)
                }
                postLikeDislike.setOnClickListener{
                    if (item.likedOrNot==true){

                    }
                   listener.onLikeDislikeClicked(item,holder)
                }
//                likeIcon.setOnClickListener {
//                    item.likedOrNot
//                    ImageViewCompat.setImageTintList(postLikeDislike,
//                        ColorStateList.valueOf( context.resources.getColor(R.color.red)))
//                    listener.onLikeDislikeClicked(item)
//                }
                postComment.setOnClickListener {
                    listener.onCommentClicked(item)
                }
                postCommentCount.text=item.commentsCount.toString()


               var doubleTapView = if (item.isVideoContent())
                    userPostVideo
                else
                    postMediaContainer

                doubleTapView.setOnClickListener(object  : DoubleClickListener(){
                    override fun onDoubleClick(v: View?) {
                            job.launch {
//                                ImageViewCompat.setImageTintList(postLikeDislike,
//                                    ColorStateList.valueOf( context.resources.getColor(R.color.red)))
                                listener.onLikeDislikeClicked(item,holder)
                                val drawable= likeIcon.drawable
                                if(drawable is AnimatedVectorDrawableCompat) {
                                    drawable.start()
                                }
                                else if (drawable is AnimatedVectorDrawable)
                                    drawable.start()
                                likeIcon.visibility=View.VISIBLE
                                delay(300)
                                likeIcon.visibility=View.GONE
                            }

                    }

                })

            }

        }
    }

    inner class PostViewHolder( val postItemBinding: FragmentHomeItemCardBinding) : RecyclerView.ViewHolder(postItemBinding.root) {

        var exoPlayer: ExoPlayer? = null
        var hlsUrl: String? = null
        private var playWhenReadyBool = false
        private var currentWindow = 0
        private var playbackPosition = 0L
        private var videoView: PlayerView? = null
        var parent: View? = null
        var currentData: HomePostItem? = null
        private var cacheDataSourceFactory: CacheDataSourceFactory? = null
        val postVideo: PlayerView? = null
        val volumeController = postItemBinding.volumeController
        val volumeImage = postItemBinding.volumeImage
         var item:HomePostItem?=null


        init {
            setListeners()
        }

        private fun setListeners(){
            postItemBinding.root.setOnFocusChangeListener { v, hasFocus ->
                if (!hasFocus||!v.hasFocus())
                    pausePlaying()
            }
        }


        fun bind(post: HomePostItem) {

            postItemBinding.apply {

                val isImage=post.type?.uppercase() == "IMAGE"
               if (isImage){
                   userPost.visibility = View.VISIBLE
                   userPostVideo.visibility = View.GONE
                   volumeController.visibility=View.GONE
               }
                else{
                   userPost.visibility = View.INVISIBLE
                   userPostVideo.visibility = View.VISIBLE
                   volumeController.visibility=View.VISIBLE
               }
                parent = this.root
                currentData = post

                if (post.userProfilePic != null && post.userProfilePic != "") {

                    glide.load(post.userProfilePic).diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                        .into(userProfile)
                } else {
                    userProfile.setImageResource(com.bazigar.bulandawaaz.R.drawable.user_img)
                }
                postUserName.text = post.userName
//                postUserAddress.text = post.location
//                postCommentCount.text = post.commentCount.toString()


                updateLike(post)



                tvDesc.text = post.caption

                if (post.type?.uppercase() == "IMAGE") {
                        glide.load(post.postUrl).diskCacheStrategy(DiskCacheStrategy.RESOURCE)
//                            .listener(object : RequestListener<Drawable> {
//                                override fun onLoadFailed(p0: GlideException?, p1: Any?, p2: Target<Drawable>?, p3: Boolean): Boolean {
//                                     //To change body of created functions use File | Settings | File Templates.
//                                    val bitmap=
//                                        imageCache.imageData.find { it.url==post.postUrl }?.data
//                                            ?: return false
//                                    HomePostItem.setImageBitmap(bitmap)
//                                    return true
//                                }
//                                override fun onResourceReady(p0: Drawable?, p1: Any?, p2: Target<Drawable>?, p3: DataSource?, p4: Boolean): Boolean {
//                                    //do something when picture already loaded
//                                     val bitmap=(p0 as BitmapDrawable).bitmap
//                                    imageCache.imageCacheDao.upsertByReplacement()
//
//                                    return false
//                                }
//                            })
                            .into(userPost)


                } else if (post.type?.uppercase() == "VIDEO") {
                    hlsUrl = post.postUrl
                    item=post
                   videoView = userPostVideo
                }
            }
            parent!!.tag = this
        }
        fun updateLike(item: HomePostItem?) {
            postItemBinding.apply {
                item?.let { item->
                    if(item.likedOrNot == true) {
                        ImageViewCompat.setImageTintList(
                            postItemBinding.postLikeDislike,
                            ColorStateList.valueOf(context.resources.getColor(R.color.primary))
                        )
                    }
                    else{
                        ImageViewCompat.setImageTintList(
                            postItemBinding.postLikeDislike,
                            ColorStateList.valueOf(context.resources.getColor(R.color.black))
                        )
                    }
                    postLikeCount.text=item.likeCount.toString()
                }
                }

        }


        fun startPlaying() {
            exoPlayer?.play()
        }

        fun pausePlaying() {
            exoPlayer?.pause()
        }

        private val playbackStateListener = object :Player.EventListener {
            override fun onPlayerStateChanged(playWhenReady: Boolean, playbackState: Int) {
                super.onPlayerStateChanged(playWhenReady, playbackState)
                if (playbackState == ExoPlayer.STATE_ENDED) {
                    playbackPosition = 0L
                    exoPlayer?.seekTo(currentWindow, playbackPosition)
                    exoPlayer?.prepare()
                }
            }
        }

         fun initPlayer(url:String) {

            exoPlayer = ExoPlayer.Builder(context)
              .setMediaSourceFactory(mediaSourceFactory).build()
             exoPlayerInstances[item?.postId!!.toLong()] = exoPlayer!!
            val videoUri = Uri.parse(url)
            val mediaItem = MediaItem.fromUri(videoUri)
            val mediaSource = progressiveMediaSource.createMediaSource(mediaItem)
            videoView?.player = exoPlayer
            exoPlayer?.playWhenReady = true
            exoPlayer?.seekTo(0, 0)
            exoPlayer?.repeatMode = Player.REPEAT_MODE_ONE
            exoPlayer?.setMediaSource(mediaSource, true)
            exoPlayer?.prepare()
             exoPlayer?.volume=0F
        }




        fun releasePlayer() {
            exoPlayer?.run {
                playbackPosition = if (playbackState == ExoPlayer.STATE_ENDED) {
                    0
                } else {
                    this.currentPosition
                }
                playWhenReadyBool = this.playWhenReady
                currentWindow = this.currentMediaItemIndex
                removeListener(playbackStateListener)
                release()
            }
        }


    }


    fun releasePlayers() {
        exoPlayerInstances.forEach {
            it.value.release()
        }
        exoPlayerInstances.clear()
        currentPlayerInstance=null
    }



    interface PostListeners{
        fun onFollowButtonClicked(item:HomePostItem)
        fun onLikeDislikeClicked(item:HomePostItem,view:PostViewHolder)
        fun onCommentClicked(item:HomePostItem)
        fun onProfileClicked(item:HomePostItem)
        fun onMoreButtonClicked(item:HomePostItem)
    }
    fun setPostListeners(listener:PostListeners){
        this.listener=listener
    }

    fun pauseCurrentPlayer() {
        currentPlayerInstance?.pause()
    }
    fun playCurrentPlayer() {
        currentPlayerInstance?.play()
    }


}
