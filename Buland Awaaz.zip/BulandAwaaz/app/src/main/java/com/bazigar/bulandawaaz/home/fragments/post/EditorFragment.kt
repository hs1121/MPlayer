package com.bazigar.bulandawaaz.home.fragments.post

import android.app.Activity
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.lifecycleScope
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.FragmentEditorBinding
import com.bazigar.bulandawaaz.utils.AudioRecorder
import com.bazigar.bulandawaaz.utils.PathFromUri
import com.github.hiteshsondhi88.libffmpeg.FFmpeg
import com.github.hiteshsondhi88.libffmpeg.FFmpegExecuteResponseHandler
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.upstream.DefaultDataSource
import com.gowtham.library.utils.LogMessage
import com.gowtham.library.utils.TrimVideo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File


class EditorFragment(private val mediaUri: String) : Fragment() {
    //   private val args:EditorFragmentArgs by navArgs()
    private lateinit var binding: FragmentEditorBinding
    private var isRecording=false
    private lateinit var audioRecorder:AudioRecorder
     var exoPlayer :ExoPlayer?=null
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentEditorBinding.inflate(layoutInflater)
        audioRecorder = AudioRecorder("Music/BulandAwaaz",requireContext().applicationContext)
        val cR = requireActivity().contentResolver
        val type = cR.getType(Uri.parse(mediaUri))
        if (!(type?.contains("jpeg")==true||type?.contains("image")==true)) {
            binding.previewVideo.visibility = View.VISIBLE
            binding.previewImage.visibility = View.GONE
            initPlayer(mediaUri)
        } else {
            binding.previewVideo.visibility = View.GONE
            binding.previewImage.visibility = View.VISIBLE
            binding.previewImage.setImageURI(Uri.parse(mediaUri))
        }

        binding.voiceOver.setOnClickListener {
            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
            val fragmentTransaction: FragmentTransaction =
                fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.fragmentContainerView,VoiceOverFragment(Uri.parse(mediaUri)) )
            fragmentTransaction.addToBackStack(null)
            fragmentTransaction.commit()
        }
        binding.rotate.setOnClickListener {
            val path=PathFromUri.getPathFromUri(requireContext(), Uri.parse(mediaUri))
           val file= File(context?.getExternalFilesDir(null),"rotated_" + System.currentTimeMillis() + ".mp4")
            val cmd= arrayOf( "-i" , File(path).path,"-vf" ,"transpose=clock", file.path)
            lifecycleScope.launch(Dispatchers.Main) {
                FFmpeg.getInstance(requireContext())
                    .execute(cmd, object : FFmpegExecuteResponseHandler {
                        override fun onStart()  { }

                        override fun onFinish() {
                        }

                        override fun onSuccess(message: String?) {
                            Log.d("rotate", "Success : $message")
                        }

                        override fun onProgress(message: String?) = Unit

                        override fun onFailure(message: String?) {
                            Log.d("rotate", "Failed : $message")
                        }
                    })
            }
        }
        binding.trim.setOnClickListener {

            TrimVideo.activity(mediaUri)
//        .setCompressOption(new CompressOption()) //empty constructor for default compress option
                .setHideSeekBar(true)
                .start(this,startForResult);

//            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
//            val fragmentTransaction: FragmentTransaction =
//                fragmentManager.beginTransaction()
//            fragmentTransaction.replace(R.id.fragmentContainerView,TrimFragment(mediaUri,exoPlayer?.duration ))
//            fragmentTransaction.addToBackStack(null)
//            fragmentTransaction.commit()
        }
        binding.crop.setOnClickListener {
//            val outputLocation = File(context.getExternalFilesDir(null),"crop_${System.currentTimeMillis()}")
//            UCrop.of(Uri.parse(mediaUri), destinationUri)
//                .withAspectRatio(16, 9)
//                .withMaxResultSize(maxWidth, maxHeight)
//                .start(context);
        }


        return binding.root
    }

    val startForResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK &&
            result.getData() != null
        ) {
            val uri = Uri.parse(TrimVideo.getTrimmedVideoPath(result.data))

            Log.d("TAG", "Trimmed path:: " + uri)
        } else
            LogMessage.v("videoTrimResultLauncher data is null");
    }



    fun initPlayer(url: String) {
            if (exoPlayer!=null){
                exoPlayer?.release()
                exoPlayer=null
            }
        exoPlayer = ExoPlayer.Builder(requireContext())
            .setMediaSourceFactory(DefaultMediaSourceFactory(requireContext())).build()
        val videoUri = Uri.parse(url)
        val mediaItem = MediaItem.fromUri(videoUri)
        val mediaSource =
            ProgressiveMediaSource.Factory(DefaultDataSource.Factory(requireContext()))
                .createMediaSource(mediaItem)
        binding.previewVideo.player = exoPlayer
        exoPlayer?.playWhenReady = true
        exoPlayer?.seekTo(0, 0)
        exoPlayer?.repeatMode = Player.REPEAT_MODE_ONE
        exoPlayer?.setMediaSource(mediaSource, true)
        exoPlayer?.prepare()
        exoPlayer?.volume = 0F
        exoPlayer?.play()
    }

}