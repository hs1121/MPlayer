package com.bazigar.bulandawaaz.home.fragments.post

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.PopupMenu
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.video.VideoCapture
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.FragmentPostBinding
import com.bazigar.bulandawaaz.home.HomeActivity
import com.bazigar.bulandawaaz.utils.Constants.FILENAME_FORMAT
import com.bazigar.bulandawaaz.utils.Constants.MEDIA_FROM_GALLERY
import com.bazigar.bulandawaaz.utils.Constants.REQUEST_CODE_PERMISSIONS
import com.bazigar.bulandawaaz.utils.Constants.REQUIRED_PERMISSIONS
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


typealias LumaListener = (luma: Double) -> Unit

class PostFragment : Fragment() {
    private var flashOn: Boolean = false
    private lateinit var binding: FragmentPostBinding
    private var isImage = true
    private lateinit var camera: Camera
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var timerCount = 0L
    private var lensFacing = CameraSelector.DEFAULT_BACK_CAMERA
    private lateinit var activity: HomeActivity

    private lateinit var cameraExecutor: ExecutorService
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activity = requireActivity() as HomeActivity
        activity.binding.bottomNavigationView.visibility = View.GONE

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentPostBinding.inflate(layoutInflater)


        // Request camera permissions
        if (activity.allPermissionsGranted { startCamera() }) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                requireActivity(), REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS
            )
        }

        if(ContextCompat.checkSelfPermission(requireContext(),Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(requireActivity(),arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE ,Manifest.permission.MANAGE_EXTERNAL_STORAGE),
                110)
        }

        // Set up the listeners for take photo and video capture buttons
        binding.selectPhoto.setOnClickListener {
            isImage = true
            binding.selectVideo.setTextColor(resources.getColor(com.bazigar.bulandawaaz.R.color.white))
            binding.selectPhoto.setTextColor(resources.getColor(com.bazigar.bulandawaaz.R.color.primary))
        }

        binding.selectVideo.setOnClickListener {
            isImage = false
            binding.selectVideo.setTextColor(resources.getColor(com.bazigar.bulandawaaz.R.color.primary))
            binding.selectPhoto.setTextColor(resources.getColor(com.bazigar.bulandawaaz.R.color.white))
        }
        binding.rearCamera.setOnClickListener {
            flipCamera()
        }
        binding.gallery.setOnClickListener {
            val intent = Intent()
            intent.type = "video/*"
            intent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(
                Intent.createChooser(intent, "Select Video"),
                MEDIA_FROM_GALLERY
            )
//            val intent = Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
//            intent.type = ("image/* video/*");
//            startActivityForResult(intent, MEDIA_FROM_GALLERY)
        }

        binding.flash.setOnClickListener {
            if (camera.cameraInfo.hasFlashUnit()) {
                if (flashOn) {
                    flashOn = false
                    camera.cameraControl.enableTorch(false)
                    binding.flash.setImageResource(com.bazigar.bulandawaaz.R.drawable.ic_baseline_flash_off_24)
                } else {
                    flashOn = true
                    camera.cameraControl.enableTorch(true)
                    binding.flash.setImageResource(com.bazigar.bulandawaaz.R.drawable.ic_baseline_flash_on_24)
                }

            }
        }
        binding.timer.setOnClickListener {
            val popup = PopupMenu(requireContext(), it)
            val inflater = popup.menuInflater
            inflater.inflate(R.menu.timer_popup_menu, popup.menu)
            popup.show()
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.timer_duration_0 -> {
                        timerCount = 0
                        true
                    }
                    R.id.timer_duration_3 -> {
                        timerCount = 3
                        true
                    }
                    R.id.timer_duration_6 -> {
                        timerCount = 6
                        true
                    }
                    R.id.timer_duration_9 -> {
                        timerCount = 9
                        true
                    }
                    else -> false

                }

            }
        }
        binding.cameraRound.setOnClickListener {
            if (timerCount > 0) {
                binding.countDownText.visibility = View.VISIBLE
            }
            object : CountDownTimer(timerCount * 1000, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    binding.countDownText.text = ((millisUntilFinished / 1000) + 1).toString()
                }

                override fun onFinish() {
                    binding.countDownText.visibility = View.GONE
                    if (isImage) takePhoto() else captureVideo()
                }
            }.start()
        }


        cameraExecutor = Executors.newSingleThreadExecutor()

        return binding.root
    }


    private fun takePhoto() {
        // Get a stable reference of the modifiable image capture use case
        val imageCapture = imageCapture ?: return

        // Create time stamped name and MediaStore entry.
        val name = SimpleDateFormat(FILENAME_FORMAT, Locale.US)
            .format(System.currentTimeMillis())
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CameraX-Image")
            }
        }

        // Create output options object which contains file + metadata
        val outputOptions = ImageCapture.OutputFileOptions
            .Builder(
                requireActivity()!!.contentResolver,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                contentValues
            )
            .build()

        // Set up image capture listener, which is triggered after photo has
        // been taken
        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(requireContext()),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Log.e("TAG", "Photo capture failed: ${exc.message}", exc)
                }

                override fun
                        onImageSaved(output: ImageCapture.OutputFileResults) {
                    val msg = "Photo capture succeeded: ${output.savedUri}"
                    Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    Log.d("TAG", msg)
                }
            }
        )
    }

    private fun captureVideo() {
        val videoCapture = this.videoCapture ?: return

        binding.cameraRound.isEnabled = false

        val curRecording = recording
        if (curRecording != null) {
            // Stop the current recording session.
            curRecording.stop()
            recording = null
            return
        }

        // create and start a new recording session
        val name = SimpleDateFormat(FILENAME_FORMAT, Locale.US)
            .format(System.currentTimeMillis())
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CameraX-Video")
            }
        }

        val mediaStoreOutputOptions = MediaStoreOutputOptions
            .Builder(requireActivity().contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(contentValues)
            .build()
        recording = videoCapture.output
            .prepareRecording(requireContext(), mediaStoreOutputOptions)
            .apply {
                if (PermissionChecker.checkSelfPermission(
                        requireContext(),
                        Manifest.permission.RECORD_AUDIO
                    ) ==
                    PermissionChecker.PERMISSION_GRANTED
                ) {
                    withAudioEnabled()
                }
            }
            .start(ContextCompat.getMainExecutor(requireContext())) { recordEvent ->
                when (recordEvent) {
                    is VideoRecordEvent.Start -> {
                        binding.cameraRound.apply {
                            setImageResource(com.bazigar.bulandawaaz.R.drawable.ic_baseline_radio_button_unchecked_24)
                            isEnabled = true
                        }
                    }
                    is VideoRecordEvent.Finalize -> {
                        if (!recordEvent.hasError()) {
                            val msg = "Video capture succeeded: " +
                                    "${recordEvent.outputResults.outputUri}"
                            Toast.makeText(
                                requireContext().applicationContext,
                                msg,
                                Toast.LENGTH_SHORT
                            )
                                .show()
                            Log.d("TAG", msg)
                        } else {
                            recording?.close()
                            recording = null
                            Log.e(
                                "TAG", "Video capture ends with error: " +
                                        "${recordEvent.error}"
                            )
                        }
                        binding.cameraRound.apply {
                            setImageResource(com.bazigar.bulandawaaz.R.drawable.ic_baseline_radio_button_checked_24)
                            isEnabled = true
                        }
                    }
                }
            }
    }


    private fun flipCamera() {
        if (lensFacing == CameraSelector.DEFAULT_FRONT_CAMERA) lensFacing =
            CameraSelector.DEFAULT_BACK_CAMERA else if (lensFacing == CameraSelector.DEFAULT_BACK_CAMERA) lensFacing =
            CameraSelector.DEFAULT_FRONT_CAMERA
        startCamera()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(requireContext())

        cameraProviderFuture.addListener({
            // Used to bind the lifecycle of cameras to the lifecycle owner
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            // Preview
            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
                }

            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.HIGHEST))
                .build()
            videoCapture = VideoCapture.withOutput(recorder)


            imageCapture = ImageCapture.Builder().build()

            val imageAnalyzer = ImageAnalysis.Builder()
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, LuminosityAnalyzer { luma ->
                        Log.d("TAG", "Average luminosity: $luma")
                    })
                }


            // Select back camera as a default
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                // Unbind use cases before rebinding
                cameraProvider.unbindAll()

                // Bind use cases to camera
                camera = cameraProvider
                    .bindToLifecycle(
                        viewLifecycleOwner,
                        lensFacing,
                        imageCapture,
                        videoCapture,
                        preview
                    )

                if (!camera.cameraInfo.hasFlashUnit()) {
                    binding.flash.setImageResource(R.drawable.ic_baseline_no_flash_24)
                }


            } catch (exc: Exception) {
                Log.e("TAG", "Use case binding failed", exc)
            }

        }, ContextCompat.getMainExecutor(requireContext()))
    }

    private class LuminosityAnalyzer(private val listener: LumaListener) : ImageAnalysis.Analyzer {

        private fun ByteBuffer.toByteArray(): ByteArray {
            rewind()    // Rewind the buffer to zero
            val data = ByteArray(remaining())
            get(data)   // Copy the buffer into a byte array
            return data // Return the byte array
        }

        override fun analyze(image: ImageProxy) {

            val buffer = image.planes[0].buffer
            val data = buffer.toByteArray()
            val pixels = data.map { it.toInt() and 0xFF }
            val luma = pixels.average()

            listener(luma)

            image.close()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == MEDIA_FROM_GALLERY && data != null) {
            val uri = data.data
            uri?.let {
                val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
                val fragmentTransaction: FragmentTransaction =
                    fragmentManager.beginTransaction()
                fragmentTransaction.replace(R.id.fragmentContainerView,EditorFragment(uri.toString()) )
                fragmentTransaction.addToBackStack(null)
                fragmentTransaction.commit()
            }

        }

    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    override fun onDetach() {
        requireActivity().window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        super.onDetach()
    }


    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        activity.binding.bottomNavigationView.visibility = View.VISIBLE

    }


}