package com.bazigar.bulandawaaz.home.fragments.post

import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bazigar.bulandawaaz.databinding.FragmentTrimBinding
import com.bazigar.bulandawaaz.utils.PathFromUri
import com.bazigar.bulandawaaz.utils.Utils
import com.bazigar.bulandawaaz.utils.getPathFromUri
import idv.luchafang.videotrimmer.VideoTrimmerView
import java.io.File

class TrimFragment(val url: String,val duration: Long?) : Fragment(), VideoTrimmerView.OnSelectedRangeChangedListener {

    private lateinit var binding:FragmentTrimBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentTrimBinding.inflate(layoutInflater)

        val path=PathFromUri.getPathFromUri(requireContext(),Uri.parse(url))
        binding.videoTrimmerView
            .setVideo(File(path))
            .setMaxDuration(duration?:30000)                   // millis
            .setMinDuration(3_000)                    // millis
            .setFrameCountInWindow(8)
            .setExtraDragSpace(10F)                    // pixels
            .setOnSelectedRangeChangedListener(this)
            .show()

        return binding.root
    }

    override fun onSelectRange(startMillis: Long, endMillis: Long) {

    }

    override fun onSelectRangeEnd(startMillis: Long, endMillis: Long) {

    }

    override fun onSelectRangeStart() {

    }

}