package com.bazigar.bulandawaaz.home.fragments.post

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.FragmentUploadPostBinding

class UploadPostFragment : Fragment() {

    private lateinit var binding:FragmentUploadPostBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentUploadPostBinding.inflate(layoutInflater)


        return binding.root

    }

}