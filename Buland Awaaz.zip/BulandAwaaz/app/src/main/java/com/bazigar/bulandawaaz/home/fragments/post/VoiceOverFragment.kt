package com.bazigar.bulandawaaz.home.fragments.post

import android.annotation.SuppressLint
import android.content.ContentResolver
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.FragmentVoiceOverBinding
import com.bazigar.bulandawaaz.utils.AudioRecorder
import com.bazigar.bulandawaaz.utils.AudioVideoMerger
import com.bazigar.bulandawaaz.utils.PathFromUri
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.upstream.DefaultDataSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.OutputStream


class VoiceOverFragment(val videoUri:Uri) : Fragment(), AudioVideoMerger.FFMpegCallback {

    private var isRecording=false
    private var isPlaying=false
    private lateinit var binding: FragmentVoiceOverBinding
    private lateinit var audioRecorder:AudioRecorder
    private lateinit var exoPlayer:ExoPlayer
    private var isTouch=true
    var durationTime: Long=-1L
    var currentDuration=0L

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentVoiceOverBinding.inflate(layoutInflater)
        exoPlayer = ExoPlayer.Builder(requireContext())
            .setMediaSourceFactory(DefaultMediaSourceFactory(requireContext())).build()

        audioRecorder = AudioRecorder("Music/BulandAwaaz",requireContext().applicationContext)
        initPlayer(videoUri.toString())

        binding.record.setOnTouchListener { v, event ->

            return@setOnTouchListener when(event.action){
                MotionEvent.ACTION_DOWN->{

                    CoroutineScope(Dispatchers.Main).launch {
                        delay(500)
                        isTouch=false
                    }
                        if (isRecording) {
                           stopVoiceOver()
                        }
                        else {
                           startVoiceOver()
                        }
                    true
                }
                MotionEvent.ACTION_UP->{
                    if(!isTouch){
                        if (isRecording)
                            stopVoiceOver()
                    }
                    true
                }
                else->false
            }
        }



        return binding.root
    }
    private fun msToStandardTime(seconds:Long): String {
        val s: Long = seconds % 60
        val m: Long = seconds / 60 % 60
        val h: Long = seconds / (60 * 60) % 24
        return String.format("%d:%02d:%02d", h, m, s)
    }

    private fun executeVoiceOver( recordingUri: Uri?) {

        recordingUri?.let { uri ->
            lifecycleScope.launch(Dispatchers.Main) {
                val pathAudio =  PathFromUri.getPathFromUri(requireContext(), uri)
                val pathVideo =PathFromUri.getPathFromUri(requireContext(),videoUri)
                val audio = File(pathAudio)
                val video2 = File(pathVideo)
                AudioVideoMerger.with(requireContext())
                    .setAudioFile(audio) //Audio File
                    .setVideoFile(video2) //Video File
                    .setStartDuration((currentDuration).toInt())
                    .setOutputFileName("merged_" + System.currentTimeMillis() + ".mp4")
                    .setCallback(this@VoiceOverFragment)
                    .merge()
            }

        }
    }
    fun startVoiceOver(){
        exoPlayer.play()
        isRecording=true
        isPlaying=true
        currentDuration=exoPlayer.currentPosition/1000
        binding.play.setImageResource(com.google.android.exoplayer2.R.drawable.exo_controls_pause)
        binding.record.setImageResource(R.drawable.ic_baseline_radio_button_unchecked_24)
        audioRecorder.start()
        Toast.makeText(requireContext(), "Started", Toast.LENGTH_SHORT).show()
        val countDownTimer=object:CountDownTimer((exoPlayer.duration-exoPlayer.currentPosition),1000){
            override fun onTick(millisUntilFinished: Long) {
            }
            override fun onFinish() {
                stopVoiceOver()
                audioRecorder.stop()
                executeVoiceOver(audioRecorder.getRecordingUri())
            }
        }.start()
    }
    fun stopVoiceOver(){
        isRecording=false
        isPlaying=false
        binding.record.setImageResource(R.drawable.ic_baseline_radio_button_checked_24)
        binding.play.setImageResource(com.google.android.exoplayer2.R.drawable.exo_controls_play)
        exoPlayer.pause()
        audioRecorder.pause()
       // executeVoiceOver( audioRecorder.getRecordingUri())
        Toast.makeText(requireContext(), "paused", Toast.LENGTH_SHORT).show()
    }

    override fun onProgress(progress: String) {
        Log.i("merge_tag",progress)
    }

    override fun onSuccess(convertedFile: File) {
      val path =convertedFile.absolutePath
        exoPlayer.removeListener(playbackStateListener)
        exoPlayer.release()
        initPlayer(path)
    }

    override fun onFailure(error: Exception) {
        Log.e("merge_tag",error.message.toString())
    }

    override fun onNotAvailable(error: Exception) {

        Log.e("merge_tag",error.message.toString())
    }

    override fun onFinish() {
        Log.i("merge_tag","Finished")
    }

private val playbackStateListener=object :Player.Listener{
    override fun onPlaybackStateChanged(playbackState: Int) {
        super.onPlaybackStateChanged(playbackState)
        if (playbackState === ExoPlayer.STATE_READY && durationTime==-1L&& exoPlayer.duration>0L) {  // getting proper duratio
            durationTime= exoPlayer.duration/1000
        }

        if (playbackState==Player.STATE_ENDED){
            if (isRecording) {
                isPlaying=false
                isRecording = false
                audioRecorder.stop()
                executeVoiceOver( audioRecorder.getRecordingUri())
            }
        }
    }


}


    fun initPlayer(url: String) {

        val videoUri = Uri.parse(url)
        val mediaItem = MediaItem.fromUri(videoUri)
        val mediaSource =
            ProgressiveMediaSource.Factory(DefaultDataSource.Factory(requireContext()))
                .createMediaSource(mediaItem)
        binding.playerView.player = exoPlayer
        binding.playerControllerView.player=exoPlayer
        exoPlayer.playWhenReady = true
        exoPlayer.seekTo(0, 0)
        exoPlayer.repeatMode = Player.REPEAT_MODE_OFF
        exoPlayer.setMediaSource(mediaSource, true)
        exoPlayer.addListener(playbackStateListener)
        exoPlayer.prepare()
        exoPlayer.volume = 0F
        exoPlayer.play()
        exoPlayer.pause()


    }




    fun saveFile(text: String, existingSourceUri: Uri?) {
        try {
            val cr: ContentResolver = requireActivity().contentResolver
            val os: OutputStream? = cr.openOutputStream(existingSourceUri!!,"wr")
            os?.write(text.toByteArray())
            os?.flush()
            os?.close()
        } catch (e: java.lang.Exception) {

            Log.e("merge_tag",e.message.toString())
        }
    }

    override fun onDestroy() {
        exoPlayer.removeListener(playbackStateListener)
        exoPlayer.release()
        super.onDestroy()
    }

}