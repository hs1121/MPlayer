package com.bazigar.bulandawaaz.home.fragments.profile

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.bazigar.bulandawaaz.databinding.FragmentProfileBinding
import com.bazigar.bulandawaaz.home.HomeViewModel
import com.bazigar.bulandawaaz.home.fragments.profile.adapter.ProfilePagerAdapter
import com.bazigar.bulandawaaz.model.user.UserData
import com.bazigar.bulandawaaz.utils.ResponseDialog
import com.bumptech.glide.RequestManager
import com.google.android.material.tabs.TabLayoutMediator
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ProfileFragment : Fragment() {
    private val homeViewModel:HomeViewModel by viewModels()
    private lateinit var binding: FragmentProfileBinding

    @Inject
    lateinit var requestManager: RequestManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentProfileBinding.inflate(layoutInflater)

        val viewPager = binding.viewPager
        val tabLayout = binding.tabLayout
        val tabsList= arrayOf("Gallery", "Saved","Post")
        val adapter = ProfilePagerAdapter(activity?.supportFragmentManager!!, lifecycle)
        viewPager.adapter = adapter
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = tabsList[position]
        }.attach()

        homeViewModel.getProfileDetails{success,message,data->
            if (success)
                initUi(data)
            else
                ResponseDialog(message).show(requireActivity().supportFragmentManager,"Response")
        }



        return binding.root
    }

    private fun initUi(data: UserData?) {
        binding.apply {
            profileName.text=data?.fullName
            profileUserName.text=data?.userName
            requestManager.load(data?.profileUrl).into(profileImage)
            followCount.text=data?.followersCont
            followingCount.text=data?.followingCount
            postCount.text=data?.postCount
            profileDescription.text=data?.bio
        }
    }


}