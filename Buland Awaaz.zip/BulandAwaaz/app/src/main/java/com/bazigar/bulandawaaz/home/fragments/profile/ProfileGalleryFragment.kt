package com.bazigar.bulandawaaz.home.fragments.profile

import android.os.Bundle
import android.util.DisplayMetrics
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.bazigar.bulandawaaz.databinding.FragmentProfileGallaryBinding
import com.bazigar.bulandawaaz.home.HomeActivity
import com.bazigar.bulandawaaz.home.HomeViewModel
import com.bazigar.bulandawaaz.home.fragments.profile.adapter.ProfileAdapter
import com.bazigar.bulandawaaz.home.fragments.profile.adapter.ProfilePagerAdapter
import com.bumptech.glide.RequestManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

const val COLUMN_COUNT = 3

@AndroidEntryPoint
class ProfileGalleryFragment : Fragment() {

    @Inject
    lateinit var requestManager: RequestManager

    private lateinit var binding: FragmentProfileGallaryBinding
    private lateinit var profileAdapter: ProfileAdapter
    private val homeViewModel=HomeViewModel.getInstance()!!
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentProfileGallaryBinding.inflate(layoutInflater)
        profileAdapter = ProfileAdapter(requestManager)
        binding.recyclerView.apply {
            layoutManager = GridLayoutManager(requireContext(), COLUMN_COUNT).apply {
                val displayMetrics = DisplayMetrics()
                requireActivity().windowManager.defaultDisplay.getMetrics(displayMetrics)
                var width = displayMetrics.widthPixels

            }
            this.adapter = profileAdapter
        }

        homeViewModel.profileGalleryState.observe(viewLifecycleOwner) { data ->
            profileAdapter.submitData(viewLifecycleOwner.lifecycle, data)
        }


        return binding.root
    }
}