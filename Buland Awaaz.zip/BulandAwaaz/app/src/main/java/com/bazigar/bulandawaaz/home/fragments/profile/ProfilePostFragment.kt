package com.bazigar.bulandawaaz.home.fragments.profile

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.FragmentProfilePostBinding

class ProfilePostFragment : Fragment() {
 private lateinit var binding:FragmentProfilePostBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentProfilePostBinding.inflate(layoutInflater)

        return binding.root
    }

}