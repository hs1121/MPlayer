package com.bazigar.bulandawaaz.home.fragments.profile

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.FragmentProfileSavedBinding

class ProfileSavedFragment : Fragment() {

    private lateinit var binding:FragmentProfileSavedBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentProfileSavedBinding.inflate(layoutInflater)

        return binding.root
    }

}