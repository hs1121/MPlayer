package com.bazigar.bulandawaaz.home.fragments.profile.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bazigar.bulandawaaz.databinding.ProfileListItemBinding
import com.bazigar.bulandawaaz.model.user.UserPost
import com.bumptech.glide.RequestManager
import com.bumptech.glide.load.engine.DiskCacheStrategy

class ProfileAdapter(
    private val requestManager: RequestManager
) : PagingDataAdapter<UserPost, ProfileAdapter.ProfileViewHolder>(diffUtil) {

    companion object {
        val diffUtil = object : DiffUtil.ItemCallback<UserPost>() {
            override fun areItemsTheSame(
                oldItem: UserPost,
                newItem: UserPost
            ): Boolean = oldItem.postId == newItem.postId

            override fun areContentsTheSame(
                oldItem: UserPost,
                newItem: UserPost
            ): Boolean = oldItem == newItem

        }
    }

    private var onItemClickListener: ((UserPost) -> Unit)? = null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileViewHolder {
        val binding = ProfileListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProfileViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProfileViewHolder, position: Int) {
        getItem(position)?.apply {

            holder.binding.apply {
                requestManager.load(thumbUrl).into(profileItemImage)
            }
        }
    }

    inner class ProfileViewHolder( val binding: ProfileListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

    }


    fun setOnItemClickListener(listener: (UserPost) -> Unit) {
        onItemClickListener = listener
    }
}