package com.bazigar.bulandawaaz.home.fragments.profile.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.bazigar.bulandawaaz.home.fragments.profile.ProfileGalleryFragment
import com.bazigar.bulandawaaz.home.fragments.profile.ProfilePostFragment
import com.bazigar.bulandawaaz.home.fragments.profile.ProfileSavedFragment


private const val NUM_TABS = 3

class ProfilePagerAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle) :
    FragmentStateAdapter(fragmentManager, lifecycle) {

    override fun getItemCount(): Int {
        return NUM_TABS
    }

    override fun createFragment(position: Int): Fragment {
        when (position) {
            0 -> return ProfileGalleryFragment()
            1 -> return ProfileSavedFragment()
        }
        return ProfilePostFragment()
    }

}
