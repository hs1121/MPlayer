package com.bazigar.bulandawaaz.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bazigar.bulandawaaz.business.datasource.LogInRepository
import com.bazigar.bulandawaaz.model.user.UserData
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LogInViewModel@Inject constructor(
    private val logInRepository: LogInRepository
):ViewModel() {

    fun login(usernameOrEmail: String, password: String,callback:(Boolean,String?)->Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            logInRepository.logIn(usernameOrEmail,password,callback)
        }
    }

//    fun signUp(
//        fullName: String,
//        email: String,
//        username: String,
//        password: String,
//        callback: (Boolean, String?) -> Unit
//    ) {
//        viewModelScope.launch {
//            logInRepository.signUp(fullName,email,username,password,callback)
//        }
//    }
     fun signUp(
    entity: UserData,
    callback: (Boolean, String?) -> Unit
    ) {
         viewModelScope.launch {
             logInRepository.signUp(entity, callback)
         }
     }

         fun sendOtp(email: String, callback: (Boolean, String?, Long?) -> Unit) {
             viewModelScope.launch(Dispatchers.IO) {
                 logInRepository.sendOtp(email, callback)
             }
         }

         fun verifyOtp(userId: Long, otp: String, callback: (Boolean, String?) -> Unit) {
             viewModelScope.launch(Dispatchers.IO) {
                 logInRepository.verifyOtp(userId, otp, callback)
             }
         }

         fun userNameExist(userName: String, callback: (Boolean, String?) -> Unit) {
             viewModelScope.launch(Dispatchers.IO) {
                 logInRepository.userNameExists(userName, callback)
             }
         }

        fun updateLocation(userId: Long, state: String, longitude: Double, latitude: Double, city: String, country: String, callback: (Boolean, String?) -> Unit){
            viewModelScope.launch {
                logInRepository.updateLocation(userId,state,longitude,latitude,city,country,callback)
            }
        }


}