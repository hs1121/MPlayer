package com.bazigar.bulandawaaz.login

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavController
import androidx.navigation.NavDirections
import androidx.navigation.fragment.NavHostFragment
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.databinding.ActivityLoginBinding
import com.bazigar.bulandawaaz.login.fragments.SignInFragmentDirections
import com.bazigar.bulandawaaz.login.fragments.SignUpFragmentDirections
import com.bazigar.bulandawaaz.model.user.UserData
import com.bazigar.bulandawaaz.utils.Constants.LOCATION_PERMISSION_REQUEST_CODE
import com.bazigar.bulandawaaz.utils.Constants.RC_SIGN_IN
import com.bazigar.bulandawaaz.utils.Constants.RC_SIGN_UP
import com.bazigar.bulandawaaz.utils.Constants.TYPE_GOOGLE_LOGIN
import com.bazigar.bulandawaaz.utils.DataStoreKeys.LOCATION
import com.bazigar.bulandawaaz.utils.DataStoreKeys.USER_ID
import com.bazigar.bulandawaaz.utils.ResponseDialog
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject
import com.google.android.gms.auth.api.signin.GoogleSignInClient as GoogleSignInClient1


@AndroidEntryPoint
class LoginActivity : AppCompatActivity() {


    private lateinit var navController: NavController
    private lateinit var binding: ActivityLoginBinding
    lateinit var locationManager: LocationManager
    private var locationCallBack: ((Boolean, String) -> Unit)? = null
    private val loginViewModel: LogInViewModel by viewModels()
    private lateinit var mGoogleSignInClient: GoogleSignInClient1
    private lateinit var  navHostFragment:NavHostFragment


    @Inject
    lateinit var dataStore: AppDataStore
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
         navHostFragment =
            supportFragmentManager.findFragmentById(R.id.login_fragment_container_view) as NavHostFragment
        navController = navHostFragment.navController


        val gso = GoogleSignInOptions
            .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.firebase_web_clint_id))
            .requestEmail()
            .build()

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);


        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE),108)


    }

    override fun onStart() {
        super.onStart()
//        val account = GoogleSignIn.getLastSignedInAccount(this)
//        updateUI(account)
    }

    private fun updateUI(currentUser: GoogleSignInAccount?,action:NavDirections) {
        val entity= UserData()
        currentUser?.apply {
            entity.fullName=displayName
            entity.email=email
            entity.profileUrl= photoUrl.toString()
            entity.googleSignInToken=currentUser.idToken.toString()
            entity.signUpType=TYPE_GOOGLE_LOGIN
            entity.userName=currentUser.email
        }
        loginViewModel.signUp(entity){success,message->
            if (success)
                navController.navigate(action)
            else
                ResponseDialog(message).show(supportFragmentManager,"Response")
        }
    }

     fun signIn(requestCode: Int) {
        val signInIntent = mGoogleSignInClient.signInIntent
        startActivityForResult(signInIntent, requestCode)
    }

    private fun handleSignInResult(
        completedTask: Task<GoogleSignInAccount>,
        action:NavDirections
    ) {
        try {
            val account = completedTask.getResult(ApiException::class.java)

            updateUI(account,action)
        } catch (e: ApiException) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w("handleSignIn", "signInResult:failed code=" + e.statusCode)
            updateUI(null,action)
        }
    }


    private val locationListener = LocationListener { location ->
        val latitute = location.latitude
        val longitute = location.longitude

        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses: List<Address> = geocoder.getFromLocation(latitute, longitute, 1)
        val cityName: String? = addresses[0].locality
        val stateName: String? = addresses[0].adminArea
        val countryName: String? = addresses[0].countryName
        Log.i("Address  ", "city: $cityName ; state: $stateName")
        Log.i("Location ", "Latitute: $latitute ; Longitute: $longitute")


        lifecycleScope.launch {
            val userId = dataStore.readValue(USER_ID)?.toLong()
            userId?.let {
                loginViewModel.updateLocation(
                    it,
                    stateName ?: "",
                    longitute,
                    latitute,
                    cityName ?: "",
                    countryName ?: ""
                ) {success,message->
                   Log.d("LocationUpdate",message?:"")

                }
            }

            dataStore.setValue(LOCATION, stateName ?: cityName ?: "")
        }


    }


    fun getLocation(callback: ((Boolean, String) -> Unit)? = null) {
        locationCallBack = callback

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            return
        }
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        locationManager!!.requestLocationUpdates(
            LocationManager.NETWORK_PROVIDER,
            0L,
            0f,
            locationListener
        )
        callback?.let { it(true, "Success") }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            when (grantResults[0]) {
                PackageManager.PERMISSION_GRANTED -> getLocation()
                PackageManager.PERMISSION_DENIED -> Toast.makeText(
                    this,
                    "Please provide location permission",
                    Toast.LENGTH_SHORT
                )
                    .show()
            }
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task,SignInFragmentDirections.actionSingInFragmentToSelectLocationFragment())
        }
        else if (requestCode == RC_SIGN_UP) {
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task,SignUpFragmentDirections.actionSignUpFragmentToSelectLocationFragment())
        }

    }


}