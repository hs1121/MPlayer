package com.bazigar.bulandawaaz.login.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.databinding.StateCardItemLayoutBinding

class LocationListAdapter(
    private val context: Context,
    private var stateList:ArrayList<String>,
    private val onClick:(Int)->Unit): RecyclerView.Adapter<LocationListAdapter.LocationViewHolder>() {
    private var selectedPos=0


    class LocationViewHolder(val binding:StateCardItemLayoutBinding): RecyclerView.ViewHolder(binding.root) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LocationViewHolder {
       val view= StateCardItemLayoutBinding.inflate(LayoutInflater.from(parent.context))
        return LocationViewHolder(view)
    }

    override fun onBindViewHolder(holder: LocationViewHolder, position: Int) {
       holder.binding.apply {
           if (selectedPos==position){
               itemLayout.setCardBackgroundColor(ContextCompat.getColor(context, R.color.selected))
               item.setTextColor(ContextCompat.getColor(context, R.color.white))
           }else{
               itemLayout.setCardBackgroundColor(ContextCompat.getColor(context, R.color.unselected))
               item.setTextColor(ContextCompat.getColor(context, R.color.text_secondary))
           }
           item.text=stateList[position]
           itemLayout.setOnClickListener {
               onClick(position)
           }
       }


    }

    override fun getItemCount(): Int {
       return stateList.size
    }

    fun updateSelectedPosition(position: Int){
        val prevPos=selectedPos
        selectedPos=position
        notifyItemChanged(selectedPos)
        notifyItemChanged(prevPos)

    }
    fun updateList(list:ArrayList<String>){
        this.stateList=list
        notifyDataSetChanged()
    }
}

