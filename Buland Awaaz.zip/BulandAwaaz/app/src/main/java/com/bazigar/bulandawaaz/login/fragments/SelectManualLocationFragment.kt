package com.bazigar.bulandawaaz.login.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.doOnTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.business.datasource.datastore.AppDataStore
import com.bazigar.bulandawaaz.databinding.FragmentSelectManualLocationBinding
import com.bazigar.bulandawaaz.home.HomeActivity
import com.bazigar.bulandawaaz.login.adapters.LocationListAdapter
import com.bazigar.bulandawaaz.utils.DataStoreKeys.LOCATION
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject
import kotlin.collections.ArrayList

@AndroidEntryPoint
class SelectManualLocationFragment : Fragment() {
 private lateinit var binding:FragmentSelectManualLocationBinding
 private lateinit var locationListAdapter:LocationListAdapter
  private lateinit var stateList:ArrayList<String>
 private var selectedLocation=""
    @Inject
    lateinit var dataStore: AppDataStore
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentSelectManualLocationBinding.inflate(layoutInflater)
        stateList= resources.getStringArray(R.array.india_states).toCollection(ArrayList())
        locationListAdapter=LocationListAdapter(requireContext(),stateList){pos->
            selectedLocation=stateList[pos]
            locationListAdapter.updateSelectedPosition(pos)
        }
        binding.apply {
            recyclerView.layoutManager=GridLayoutManager(requireContext(),2).apply {

            }
            recyclerView.adapter=locationListAdapter
        }
        setUpListeners()

        return binding.root
    }

    private fun setUpListeners() {
        binding.apply {
            backBtn.setOnClickListener {
                activity?.onBackPressed()
            }

            continueBtn.setOnClickListener {
                if (selectedLocation==null)
                    Toast.makeText(
                        requireContext().applicationContext,
                        "Select a location",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                    else
                lifecycleScope.launch(Dispatchers.Main) {
                    dataStore.setValue(LOCATION,selectedLocation)
                    startActivity(Intent(requireContext().applicationContext,HomeActivity::class.java))
                    activity?.finish()
                }

            }

            searchLocationText.doOnTextChanged { text, start, before, count ->
                text?.toString()?.let { searchText->
                    val list= stateList.filter { it.lowercase().contains(searchText.lowercase()) }.toCollection(ArrayList())
                    locationListAdapter.updateList(list)


                }

            }
        }

    }

}