package com.bazigar.bulandawaaz.login.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.bazigar.bulandawaaz.R
import com.bazigar.bulandawaaz.business.datasource.network.login.SignInService
import com.bazigar.bulandawaaz.databinding.FragmentLogInBinding
import com.bazigar.bulandawaaz.home.HomeActivity
import com.bazigar.bulandawaaz.login.LogInViewModel
import com.bazigar.bulandawaaz.login.LoginActivity
import com.bazigar.bulandawaaz.utils.Constants.RC_SIGN_IN
import com.bazigar.bulandawaaz.utils.ResponseDialog
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SignInFragment : Fragment() {

    @Inject
    lateinit var signInService: SignInService
    private val logInViewModel: LogInViewModel by viewModels()

    private lateinit var binding: FragmentLogInBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentLogInBinding.inflate(layoutInflater)
        setClickListeners()
        return binding.root
    }

    private fun setClickListeners() {
        binding.apply {
            signInButton.setOnClickListener {
                val usernameOrEmail = usernameEmailText.text.toString()
                val password = passwordText.text.toString()
                if (usernameOrEmail.isNullOrEmpty())
                    usernameEmailText.error = "Field cannot be empty"
                else if (password.isNullOrEmpty())
                    passwordText.error = "Field cannot be empty"
                else
                    logInViewModel.login(usernameOrEmail, password) { success, message ->
                        if (success) {

                            val action = SignInFragmentDirections.actionSingInFragmentToSelectLocationFragment()
                            findNavController().navigate(action)
//                            startActivity(Intent(requireContext().applicationContext,HomeActivity::class.java))
//                        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()


                        }
                        else
                            ResponseDialog(message).show(parentFragmentManager,"Response")
                    }
            }
            signUpButton.setOnClickListener {
                val action = SignInFragmentDirections.actionSingInFragmentToSignUpFragment()
                findNavController().navigate(action)
            }

            iconGoogle.setOnClickListener {
                val activity=activity as LoginActivity
                activity.signIn(RC_SIGN_IN)
            }
        }
    }
}


