package com.bazigar.bulandawaaz.login.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.bazigar.bulandawaaz.databinding.FragmentSignUpBinding
import com.bazigar.bulandawaaz.login.LogInViewModel
import com.bazigar.bulandawaaz.login.LoginActivity
import com.bazigar.bulandawaaz.model.user.UserData
import com.bazigar.bulandawaaz.utils.Constants
import com.bazigar.bulandawaaz.utils.ResponseDialog
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SignUpFragment : Fragment() {

    private lateinit var binding:FragmentSignUpBinding
    private val logInViewModel:LogInViewModel by viewModels()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentSignUpBinding.inflate(layoutInflater)
        setupClickListeners()
        return binding.root
    }

    private fun setupClickListeners() {
        binding.apply {
            signInButton.setOnClickListener {
                val action = SignUpFragmentDirections.actionSignUpFragmentToSingInFragment()
                findNavController().navigate(action)
            }
            signUpButton.setOnClickListener {
                val fullName = nameText.text.toString()
                val email = emailText.text.toString()
                val username = usernameText.text.toString()
                val password = passwordText.text.toString()

                if (fullName.isNullOrEmpty())
                    nameText.error = "Name cannot be empty"
                else if (email.isNullOrEmpty())
                    emailText.error = "Email cannot be empty"
                else if (!email.contains("@") || !email.contains("."))
                    emailText.error = "Please provide proper email"
                else if (username.isNullOrEmpty())
                    usernameText.error = "Username cannot be empty"
                else if (password.isNullOrEmpty())
                    passwordText.error = "Password cannot be empty"
                else {
                    val data = UserData()
                    data.fullName = fullName
                    data.email = email
                    data.userName = username
                    data.userPassword = password
                    logInViewModel.userNameExist(username) { success, message ->
                        if (success) {
                            val action =
                                SignUpFragmentDirections.actionSignUpFragmentToVerifyOtpFragment(data)
                            findNavController().navigate(action)
                        } else {
                            ResponseDialog(message).show(parentFragmentManager, "Response")
                        }
                    }

                }

            }
            iconGoogle.setOnClickListener {
                val activity = activity as LoginActivity
                activity.signIn(Constants.RC_SIGN_IN)
            }
        }
    }


}