package com.bazigar.bulandawaaz.login.fragments

import android.os.Bundle
import android.os.CountDownTimer
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.bazigar.bulandawaaz.databinding.FragmentVerifyOtpBinding
import com.bazigar.bulandawaaz.login.LogInViewModel
import com.bazigar.bulandawaaz.model.user.UserData
import com.bazigar.bulandawaaz.utils.ResponseDialog
import dagger.hilt.android.AndroidEntryPoint
import java.lang.Exception

@AndroidEntryPoint
class VerifyOtpFragment : Fragment() {

    private lateinit var binding: FragmentVerifyOtpBinding
    private var allowResendOtp = false
    private val logInViewModel: LogInViewModel by viewModels()
    private val args: VerifyOtpFragmentArgs by navArgs()
    private var userId: Long? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentVerifyOtpBinding.inflate(layoutInflater)
        setClickListeners()
        logInViewModel.sendOtp(args.userdata.email!!) { success, message, userId ->
            if (success) {
                this@VerifyOtpFragment.userId = userId
            } else
                ResponseDialog(message).show(parentFragmentManager,"Response")
        }
        timer.start()
        return binding.root
    }


    private fun setClickListeners() {
        binding.apply {
            resendText.setOnClickListener {
                if (allowResendOtp) {
                    allowResendOtp = false
                    logInViewModel.sendOtp(args.userdata.email!!) { success, message, userId ->
                        if (success) {
                            this@VerifyOtpFragment.userId = userId
                        } else
                            ResponseDialog(message).show(parentFragmentManager,"Response")
                    }
                    timer.start()
                }
            }

            verifyBtn.setOnClickListener {
                val otp = otpText.text.toString()
//                val allNumbers= try {
//                    otp.toLong()
//                    true
//                }catch (e:Exception){
//                    false
//                }
                if (otp.isEmpty())
                    otpText.error = "Enter Otp"
                else if (userId == null)
                    Toast.makeText(
                        requireContext().applicationContext,
                        "Something went wrong",
                        Toast.LENGTH_SHORT
                    ).show()
                else
                    logInViewModel.verifyOtp(userId!!, otp) { success, message ->
                        if (success) {
                            registerUser(args.userdata)
                        } else
                            ResponseDialog(message).show(parentFragmentManager,"Response")
                    }

            }
        }
    }

//    private fun registerUser(userdata: Data) {
//        userdata.apply {
//            try {
//                logInViewModel.signUp(
//                    fullName!!,
//                    email!!,
//                    userName!!,
//                    userPassword!!
//                ) { success, message ->
//                    run {
//                        if (success) {
//                            val action =
//                                VerifyOtpFragmentDirections.actionVerifyOtpFragmentToSelectLocationFragment()
//                            findNavController().navigate(action)
//                        }
//                        Toast.makeText(
//                            requireContext().applicationContext,
//                            message,
//                            Toast.LENGTH_SHORT
//                        )
//                            .show()
//
//                    }
//                }
//            } catch (e: Exception) {
//                Toast.makeText(
//                    requireContext().applicationContext,
//                    e.message.toString(),
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
//
//        }
//    }


    private fun registerUser(userdata: UserData) {
        userdata.apply {
            try {
                logInViewModel.signUp(
                    userdata
                ) { success, message ->
                    run {
                        if (success) {
                            val action =
                                VerifyOtpFragmentDirections.actionVerifyOtpFragmentToSelectLocationFragment()
                            findNavController().navigate(action)
                        }
                        Toast.makeText(
                            requireContext().applicationContext,
                            message,
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    }
                }
            } catch (e: Exception) {
                Toast.makeText(
                    requireContext().applicationContext,
                    e.message.toString(),
                    Toast.LENGTH_SHORT
                ).show()
            }

        }
    }


    private val timer = object : CountDownTimer(30 * 1000, 1000) {
        override fun onTick(millisUntilFinished: Long) {
            val timeLift = millisUntilFinished / 1000
            binding.resendText.text = "Resend OTP in $timeLift sec"
        }

        override fun onFinish() {
            binding.resendText.text = "Resend OTP"
            allowResendOtp = true
        }

    }


}