package com.bazigar.bulandawaaz.model.comment


data class CommentEntity(
    val commentId: Long=0L,
    val postId: Long? = 0L,
    val userId: Long? = 0L,
    var comment: String?="",
    var replyCount: Int=0,
    var likeCount: Int=0,
    var likedOrNot:Boolean=false

)
