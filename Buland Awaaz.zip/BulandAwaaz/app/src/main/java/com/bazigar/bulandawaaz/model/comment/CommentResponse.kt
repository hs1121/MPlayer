package com.bazigar.bulandawaaz.model.comment

import com.bazigar.bulandawaaz.model.responses.Status
import com.google.gson.annotations.SerializedName

data class CommentResponse(
    @SerializedName("message")
    val message: String,

    @SerializedName("status")
    val status: Status,

    @SerializedName("data")
    val data: ArrayList<CommentEntity>
) {
    fun toCommentEntity(): List<CommentEntity> {
        return data
    }
}
