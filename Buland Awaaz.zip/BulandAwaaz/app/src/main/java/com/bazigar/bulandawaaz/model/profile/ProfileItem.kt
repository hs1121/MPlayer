package com.bazigar.bulandawaaz.model.profile

data class ProfileItem(
    val id: String,
    val url: String
)