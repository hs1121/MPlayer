package com.bazigar.bulandawaaz.model.responses

import com.google.gson.annotations.SerializedName

data class Status(

    @field:SerializedName("responseReason")
    var responseReason: String? = null,

    @field:SerializedName("responseCode")
    var responseCode: Int? = null
)
