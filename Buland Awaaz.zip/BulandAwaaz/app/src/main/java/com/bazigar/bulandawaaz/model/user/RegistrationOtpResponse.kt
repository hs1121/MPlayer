package com.bazigar.bulandawaaz.model.user

import com.bazigar.bulandawaaz.model.responses.Status
import com.google.gson.annotations.SerializedName

data class RegistrationOtpResponse(

	@field:SerializedName("data")
	val data: Long? = null,

	@field:SerializedName("message")
	val message: String? = null,

	@field:SerializedName("status")
	val status: Status? = null
)


