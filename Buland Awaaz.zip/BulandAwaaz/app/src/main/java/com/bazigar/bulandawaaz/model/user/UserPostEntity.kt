package com.bazigar.bulandawaaz.model.user

import com.google.gson.annotations.SerializedName

data class UserPostEntity(

	@field:SerializedName("postUrl")
	val postUrl: String? = null,

	@field:SerializedName("caption")
	val caption: String? = null,

	@field:SerializedName("likeCount")
	val likeCount: Int? = null,

	@field:SerializedName("postId")
	val postId: Int? = null,

	@field:SerializedName("userName")
	val userName: String? = null,

	@field:SerializedName("type")
	val type: String? = null,

	@field:SerializedName("likedOrNot")
	val likedOrNot: Boolean? = null,

	@field:SerializedName("createdAt")
	val createdAt: Long? = null,

	@field:SerializedName("hashTags")
	val hashTags: String? = null,

	@field:SerializedName("userProfilePic")
	val userProfilePic: String? = null,

	@field:SerializedName("commentsCount")
	val commentsCount: Int? = null,

	@field:SerializedName("savedOrNot")
	val savedOrNot: Boolean? = null,

	@field:SerializedName("mentions")
	val mentions: String? = null,

	@field:SerializedName("thumbUrl")
	val thumbUrl: String? = null,

	@field:SerializedName("hlsUrl")
	val hlsUrl: String? = null
)
