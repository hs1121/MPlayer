package com.bazigar.bulandawaaz.model.user

import com.google.gson.annotations.SerializedName

data class UserPostResponse(

	@field:SerializedName("data")
	val data: Data = Data(),

	@field:SerializedName("message")
	val message: String? = null,

	@field:SerializedName("status")
	val status: Status? = null
)

data class Data(

	@field:SerializedName("objects")
	val objects: List<UserPost> = arrayListOf(),

	@field:SerializedName("totalPages")
	val totalPages: Int = 0,

	@field:SerializedName("currentPage")
	val currentPage: Int = 0
)

data class UserPost(

	@field:SerializedName("postUrl")
	val postUrl: String? = null,

	@field:SerializedName("caption")
	val caption: String? = null,

	@field:SerializedName("likeCount")
	val likeCount: Int? = null,

	@field:SerializedName("postId")
	val postId: Int? = null,

	@field:SerializedName("userName")
	val userName: String? = null,

	@field:SerializedName("type")
	val type: String? = null,

	@field:SerializedName("likedOrNot")
	val likedOrNot: Boolean? = null,

	@field:SerializedName("createdAt")
	val createdAt: Long? = null,

	@field:SerializedName("hashTags")
	val hashTags: String? = null,

	@field:SerializedName("userProfilePic")
	val userProfilePic: String? = null,

	@field:SerializedName("commentsCount")
	val commentsCount: Int? = null,

	@field:SerializedName("savedOrNot")
	val savedOrNot: Boolean? = null,

	@field:SerializedName("mentions")
	val mentions: String? = null,

	@field:SerializedName("thumbUrl")
	val thumbUrl: String? = null,

	@field:SerializedName("hlsUrl")
	val hlsUrl: String? = null
)

data class Status(

	@field:SerializedName("responseReason")
	val responseReason: String? = null,

	@field:SerializedName("responseCode")
	val responseCode: Int? = null
)
