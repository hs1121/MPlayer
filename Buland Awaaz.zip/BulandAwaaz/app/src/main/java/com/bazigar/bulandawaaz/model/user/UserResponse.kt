package com.bazigar.bulandawaaz.model.user

import android.os.Parcelable
import androidx.room.Entity
import com.bazigar.bulandawaaz.model.responses.Status
import com.bazigar.bulandawaaz.utils.DataBaseKeys.USER_TABLE
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize


data class UserResponse (

	@field:SerializedName("data")
	var data: UserData? = null,

	@field:SerializedName("message")
	var message: String? = null,

	@field:SerializedName("status")
	var status: Status? = null
)



@Parcelize
@Entity(tableName = USER_TABLE)
data class UserData(

	@field:SerializedName("profileUrl")
	var profileUrl: String? = null,

	@field:SerializedName("flag")
	var flag: Boolean? = null,

	@field:SerializedName("access")
	var access: Int? = null,

	@field:SerializedName("gender")
	var gender: String? = null,

	@field:SerializedName("verified")
	var verified: Boolean? = null,

	@field:SerializedName("fullName")
	var fullName: String? = null,

	@field:SerializedName("bio")
	var bio: String? = null,

	@field:SerializedName("userName")
	var userName: String? = null,

	@field:SerializedName("followingCount")
	var followingCount: String? = null,

	@field:SerializedName("phoneNo")
	var phoneNo: String? = null,

	@field:SerializedName("token")
	var token: String? = null,

	@field:SerializedName("createdAt")
	var createdAt: Long? = null,

	@field:SerializedName("firebaseToken")
	var firebaseToken: String? = null,

	@field:SerializedName("dob")
	var dob: String? = null,

	@field:SerializedName("postCount")
	var postCount: String? = null,

	@field:SerializedName("id")
	var id: Int? = null,

	@field:SerializedName("followersCont")
	var followersCont: String? = null,

	@field:SerializedName("email")
	var email: String? = null,

	@field:SerializedName("updatedAt")
	var updatedAt: Long? = null,
	@field:SerializedName("deviceName")
	val deviceName: String?=null,
	@field:SerializedName("signUpType")
	var signUpType:String?=null,
	@field:SerializedName("googleSignInToken")
	var googleSignInToken:String?=null,
	var userPassword:String?=null  //  for signup purpose
) : Parcelable {

}
