package com.bazigar.bulandawaaz.utils

import android.R.attr.path
import android.content.ContentValues
import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.File
import java.io.IOException
import java.lang.Exception
import java.time.Duration

const val PATH="Music/BulandAwaaz/"
class AudioRecorder(path: String, val context: Context) {

    var fileName: String? = "Record.aac"
    var recorder: MediaRecorder? = MediaRecorder()
    var audiouri: Uri? = null
    var file: ParcelFileDescriptor? = null
    private var maxDuration=0




    var filePath: String? = null
    init {
       filePath=sanitizePath(path)
    }
    fun setMaxDuration(maxDuration:Int){
        this.maxDuration=maxDuration
    }

    private fun sanitizePath(path: String): String {
        var path = path
        if (!path.startsWith("/")) {
            path = "/Music/BulandAwaaz/"
        }
        if (!path.contains(".")) {
            path += "${System.currentTimeMillis()}.aac"
        }
        context.getExternalFilesDir(Environment.getExternalStorageDirectory().absolutePath
                + path)
        return (Environment.getExternalStorageDirectory().absolutePath
                + path)
    }

    @Throws(IOException::class)
    fun start() {
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q) {
            val values = ContentValues(4)
            values.put(MediaStore.Audio.Media.TITLE, fileName)
            values.put(
                MediaStore.Audio.Media.DATE_ADDED,
                (System.currentTimeMillis() / 1000).toInt()
            )
            values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/aac")

            values.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/BulandAwaaz/")
            audiouri =
                context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            file = context.contentResolver.openFileDescriptor(audiouri!!, "w")
            if (file != null) {
                recorder!!.setAudioSource(MediaRecorder.AudioSource.MIC)
                recorder!!.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                recorder!!.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                recorder!!.setOutputFile(file!!.fileDescriptor)
                recorder!!.setAudioChannels(1)
                recorder!!.prepare()
                recorder!!.start()
            }
        }
        else {

            val state = Environment.getExternalStorageState()
            if (state != Environment.MEDIA_MOUNTED) {
                throw IOException(
                    "SD Card is not mounted.  It is " + state
                            + "."
                )
            }

            // make sure the directory we plan to store the recording in exists
            // make sure the directory we plan to store the recording in exists
            val directory: File = File(filePath).parentFile
            if (!directory.exists() && !directory.mkdirs()) {
                throw IOException("Path to file could not be created.")
            }

            recorder!!.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder!!.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
            recorder!!.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
            recorder!!.setOutputFile(filePath)
            recorder!!.prepare()
            recorder!!.start()
        }
    }

    @Throws(IOException::class)
    fun stop() {
        try {
            recorder?.stop()
            recorder?.release()
        }catch (e:Exception){}

    }
    @Throws(IOException::class)
    fun pause() {
        try {
            if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.N)
            recorder?.pause()
            else
                stop()
        }catch (e:Exception){}

    }

    fun getRecordingUri()= audiouri

    @Throws(IOException::class)
    fun playaRecording(path: String?) {
        val mp = MediaPlayer()
        mp.setDataSource(path)
        mp.prepare()
        mp.start()
        mp.setVolume(10f, 10f)
    }

fun getRecorderInstance()=recorder


}