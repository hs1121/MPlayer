package com.bazigar.bulandawaaz.utils;

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.room.CoroutinesRoom.Companion.execute

import com.bazigar.bulandawaaz.utils.Constants.TYPE_VIDEO
import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler
import com.github.hiteshsondhi88.libffmpeg.FFmpeg
import com.github.hiteshsondhi88.libffmpeg.FFmpegExecuteResponseHandler
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException


class AudioVideoMerger( val context:Context) {

    private var audio: File? = null
    private var video: File? = null
    private var callback: FFMpegCallback? = null
    private var outputPath = ""
    private var outputFileName = ""
    private var startDuration=0
    var fFmpeg: FFmpeg? = null

    fun setAudioFile(originalFiles: File): AudioVideoMerger {
        this.audio = originalFiles
        return this
    }

    fun setVideoFile(originalFiles: File): AudioVideoMerger {
        this.video = originalFiles
        return this
    }
    fun setStartDuration(startProgress: Int):AudioVideoMerger {
        this.startDuration=startProgress
        return this
    }

    fun setCallback(callback: FFMpegCallback): AudioVideoMerger {
        this.callback = callback
        return this
    }

    fun setOutputPath(output: String): AudioVideoMerger {
        this.outputPath = output
        return this
    }

    fun setOutputFileName(output: String): AudioVideoMerger {
        this.outputFileName = output
        return this
    }

    fun merge() {

//        if (audio == null || !audio!!.exists() || video == null || !video!!.exists()) {
//            callback!!.onFailure(IOException("File not exists"))
//            return
//        }
//        if (!audio!!.canRead() || !video!!.canRead()) {
//            callback!!.onFailure(IOException("Can't read the file. Missing permission?"))
//            return
//        }

        val outputLocation = File(context.getExternalFilesDir(null),outputFileName)//Utils.getConvertedFile(outputPath, outputFileName)
        val cmd = arrayOf("-i", video!!.path, "-i", audio!!.path, "-c:v", "copy", "-c:a", "aac", "-strict", "experimental", "-map", "0:v:0", "-map", "1:a:0", "-shortest", outputLocation.path)
       // val cmd = arrayOf("-i", video!!.path,"-itsoffset ",secondToStandardTime(startDuration.toLong()), "-i", audio!!.path, "-c:v", "copy", "-c:a", "aac", "-strict", "experimental", "-map", "0:v:0", "-map", "1:a:0", "-shortest","-async 1", outputLocation.path)
    try {

        CoroutineScope(Dispatchers.Main).launch {
            val session = FFmpeg.getInstance(context).execute(cmd,object:FFmpegExecuteResponseHandler{
                override fun onStart() {

                }

                override fun onFinish() {
                    callback?.onFinish()
                    Log.d("merge","finished")
                }

                override fun onSuccess(message: String?) {
                    callback?.onSuccess(outputLocation)
                    Log.d("merge","success")
                }

                override fun onProgress(message: String?) {
                    if (message != null) {
                        callback?.onProgress(message)
                    }
                }

                override fun onFailure(message: String?) {
                    Log.d("merge","cancel")
                    callback?.onFailure(java.lang.Exception("canceled"))
                }

            })
//            if (ReturnCode.isSuccess(session.returnCode)) {
//                callback?.onSuccess(outputLocation)
//                Log.d("merge","success")
//            } else if (ReturnCode.isCancel(session.returnCode)) {
//                Log.d("merge","cancel")
//                callback?.onFailure(java.lang.Exception("canceled"))
//                // CANCEL
//            } else {
//                callback?.onFailure(java.lang.Exception(String.format(
//                    "Command failed with state %s and rc %s.%s",
//                    session.state,
//                    session.returnCode,
//                    session.failStackTrace)))
//                // FAILURE
//                Log.d(
//                    "merge",
//                    String.format(
//                        "Command failed with state %s and rc %s.%s",
//                        session.state,
//                        session.returnCode,
//                        session.failStackTrace
//                    )
//                )
//            }
        }

        } catch (e2: java.lang.Exception) {

            callback!!.onFailure(e2)
        }

    }
    companion object {

        val TAG = "AudioVideoMerger"

        fun with(context: Context): AudioVideoMerger {
            return AudioVideoMerger(context)
        }
    }
    private fun secondToStandardTime(seconds:Long): String {
        val s: Long = seconds % 60
        val m: Long = seconds / 60 % 60
        val h: Long = seconds / (60 * 60) % 24
        return String.format("%d:%02d:%02d", h, m, s)
    }



    interface FFMpegCallback{
        fun onProgress(progress: String)
        fun onSuccess( file: File)
        fun onFailure(error: Exception)
        fun onNotAvailable(error: Exception)

        fun onFinish()
    }


}

