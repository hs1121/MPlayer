package com.bazigar.bulandawaaz.utils

import android.Manifest
import android.os.Build

object Constants {


    const val APP_FOLDER= "Buland Awaaz"
    const val BASE_URL="http://192.168.1.30:8081/"
    const val USER_END_POINT = "buland-awaaz/api/User/"

    const val FIREBASE_WEB_CLINT_ID="288559127077-dm2mcf34o37r77vqg0c4suibickdfvjg.apps.googleusercontent.com"
    const val TYPE_GOOGLE_LOGIN="google_login"


    const val VIDEO_LIST = "VIDEO_LIST"
    const val TYPE_VIDEO =".mp4"
    const val TYPE_IMAGE = ".jpeg"


   const val TAG = "CameraXApp"
   const val FILENAME_FORMAT = "yyyy-MM-dd-HH-mm-ss-SSS"
   const val REQUEST_CODE_PERMISSIONS = 10
    val REQUIRED_PERMISSIONS =
        mutableListOf (
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        ).apply {
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }.toTypedArray()


    // RequestCode
    const val LOCATION_PERMISSION_REQUEST_CODE=101
    const val RC_SIGN_IN= 102
    const val RC_SIGN_UP= 103
    const val REQUEST_CODE_CAMERA=104
    const val MEDIA_FROM_GALLERY=105

}

object DataBaseKeys{
    const val USER_TABLE="UserTable"
}

object DataStoreKeys{
    const val USER_ID = "com.buland-awaazUSER_ID"
    const val FIREBASE_TOKEN = "com.buland-awaaz.FCM_TOKEN"
    const val PASSWORD= "com.buland-awaaz.PASSWORD"
    const val LOCATION= "com.buland-awaaz.LOCATION"
}




