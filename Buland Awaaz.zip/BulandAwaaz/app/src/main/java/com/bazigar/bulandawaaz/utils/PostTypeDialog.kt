package com.bazigar.bulandawaaz.utils

import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.bazigar.bulandawaaz.R

class PostTypeDialog (  val callback:(Int)->Unit
) : DialogFragment() {


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.post_type_dialog_layout, container, false)
        val textView = view.findViewById<View>(R.id.text_post)
        val mediaView = view.findViewById<View>(R.id.media_post)
        textView.setOnClickListener {
            callback(it.id)
            dismiss()
        }
        mediaView.setOnClickListener {
            callback(it.id)
            dismiss()
        }

        object : CountDownTimer(5000, 5000) {
            override fun onTick(millisUntilFinished: Long) = Unit

            override fun onFinish() {
                dismiss()
            }
        }.start()

        return view;
    }

    override fun onStart() {
        super.onStart()
        val width = (resources.displayMetrics.widthPixels * 0.85).toInt()
        val height = (resources.displayMetrics.heightPixels * 0.40).toInt()
        dialog!!.window?.setLayout(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
//        dialog!!.window?.setGravity(Gravity.BOTTOM)
        dialog!!.window?.setBackgroundDrawableResource(R.color.transparent)
    }
}