package com.bazigar.bulandawaaz.utils

import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.bazigar.bulandawaaz.R
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText



class ResponseDialog(
    private val message:String?
) :DialogFragment() {



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view =inflater.inflate(R.layout.response_dialog_layout,container,false)
        val responseMessage=view.findViewById<TextView>(R.id.response_message)
        val okBtn=view.findViewById<TextView>(R.id.text_ok)
            responseMessage.text=message
        okBtn.setOnClickListener {
            dismiss()
        }

         object :CountDownTimer(5000,5000){
            override fun onTick(millisUntilFinished: Long) =Unit

            override fun onFinish() {
               dismiss()
            }
        }.start()

        return view;
    }

    override fun onStart() {
        super.onStart()
        val width = (resources.displayMetrics.widthPixels * 0.85).toInt()
        val height = (resources.displayMetrics.heightPixels * 0.40).toInt()
        dialog!!.window?.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog!!.window?.setBackgroundDrawableResource(R.color.transparent)
    }
}