package com.bazigar.bulandawaaz.utils

import android.app.PendingIntent
import android.app.RecoverableSecurityException
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import java.io.FileInputStream
import java.io.IOException

class ScopedStorageExt {

    private var context: Context? = null
    fun with(context: Context?): ScopedStorageExt {
        this.context = context
        return this
    }

    /**
     * Create new media uri.
     */
    fun create(directory: String?, filename: String?, mimetype: String?): Uri? {
        val contentResolver = context!!.contentResolver
        val contentValues = ContentValues()

        //Set filename, if you don't system automatically use current timestamp as name
        contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename)

        //Set mimetype if you want
        contentValues.put(MediaStore.MediaColumns.MIME_TYPE, mimetype)

        //To create folder in Android directories use below code
        //pass your folder path here, it will create new folder inside directory
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, directory)
        }

        //pass new ContentValues() for no values.
        //Specified uri will save object automatically in android specified directories.
        //ex. MediaStore.Images.Media.EXTERNAL_CONTENT_URI will save object into android Pictures directory.
        //ex. MediaStore.Videos.Media.EXTERNAL_CONTENT_URI will save object into android Movies directory.
        //if content values not provided, system will automatically add values after object was written.
        return contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
    }

    /**
     * Delete file.
     *
     *
     * If [ContentResolver] failed to delete the file, use trick,
     * SDK version is >= 29(Q)? use [SecurityException] and again request for delete.
     * SDK version is >= 30(R)? use [MediaStore.createDeleteRequest].
     */
    fun delete(launcher: ActivityResultLauncher<IntentSenderRequest?>, uri: Uri) {
        val contentResolver = context!!.contentResolver
        try {

            //delete object using resolver
            contentResolver.delete(uri, null, null)
        } catch (e: SecurityException) {
            var pendingIntent: PendingIntent? = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val collection = ArrayList<Uri>()
                collection.add(uri)
                pendingIntent = MediaStore.createDeleteRequest(contentResolver, collection)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                //if exception is recoverable then again send delete request using intent
                if (e is RecoverableSecurityException) {
                    pendingIntent = e.userAction.actionIntent
                }
            }
            if (pendingIntent != null) {
                val sender = pendingIntent.intentSender
                val request = IntentSenderRequest.Builder(sender).build()
                launcher.launch(request)
            }
        }
    }

    /**
     * Rename file.
     *
     * @param uri    - filepath
     * @param rename - the name you want to replace with original.
     */
    fun rename(uri: Uri?, rename: String?) {

        //create content values with new name and update
        val contentValues = ContentValues()
        contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, rename)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context!!.contentResolver.update(uri!!, contentValues, null)
        }
    }

    /**
     * Duplicate file.
     *
     * @param uri - filepath.
     */
    fun duplicate(uri: Uri): Uri? {
        val contentResolver = context!!.contentResolver
        val output =
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, ContentValues())
        val input = getPathFromUri(uri)
        try {
            FileInputStream(input).use { inputStream ->  //input stream
                val out =
                    contentResolver.openOutputStream(output!!) //output stream
                val buf = ByteArray(1024)
                var len: Int
                while (inputStream.read(buf).also { len = it } > 0) {
                    out!!.write(buf, 0, len) //write input file data to output file
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return output
    }

    /**
     * Get file path from uri.
     */
     fun getPathFromUri(uri: Uri): String? {
        val cursor = context!!.contentResolver.query(uri, null, null, null, null)
        var text: String? = null
        if (cursor!!.moveToNext()) {
            text = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
        }
        cursor.close()
        return text
    }

    companion object {
        val instance: ScopedStorageExt
            get() = ScopedStorageExt()
    }
}