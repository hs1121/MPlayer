package com.bazigar.bulandawaaz.utils

//import android.media.MediaCodec
//import android.media.MediaExtractor
//import android.media.MediaFormat
//import android.media.MediaMuxer
//import android.util.Log
//import com.bumptech.glide.load.resource.bitmap.VideoDecoder.byteBuffer
//import java.nio.ByteBuffer
//
//
//class VideoEdit {
//    private var audioTrackIndex: Int=0
//    private var videoTrackIndex: Int=0
//    private var frameMaxInputSize: Int=0
//    private var audioFormat: MediaFormat?=null
//    private var audioPath: String=""
//    private var videoPath:String=""
//    private var outputPath:String=""
//    private var videoFormat:MediaFormat?=null
//    val  videoExtractor = MediaExtractor()
//    var  audioExtractor = MediaExtractor()
//    fun app(){
//        videoExtractor.setDataSource(videoPath)
//        var videoFormat: MediaFormat? = null
//        val videoTrackCount: Int = videoExtractor.getTrackCount()
//        //vedio max input size
//        //vedio max input size
//        var frameMaxInputSize = 0
//        var frameRate = 0
//        var videoDuration: Long = 0
//        var videoTrackIndex=0
//        for (i in 0 until videoTrackCount) {
//            videoFormat = videoExtractor.getTrackFormat(i)
//            val mimeType = videoFormat.getString(MediaFormat.KEY_MIME)
//            if (mimeType!!.startsWith("video/")) {
//                /*
//             * just use the first track
//             */
//                videoTrackIndex = i
//                frameMaxInputSize = videoFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
//                frameRate = videoFormat.getInteger(MediaFormat.KEY_FRAME_RATE)
//                videoDuration = videoFormat.getLong(MediaFormat.KEY_DURATION)
//                break
//            }
//        }
//
//        if (videoTrackIndex < 0) {
//            Log.e("TAG", "Error input file:: No Vedio track")
//            return
//        }
//    }
//
//    fun app2(){
//
//        audioExtractor.setDataSource(audioPath)
//        var audioFormat: MediaFormat? = null
//        var audioTrackIndex=0
//
//        var audioTrackCount: Int = audioExtractor.getTrackCount()
//        audioExtractor = MediaExtractor()
////        val audioTrackCount: Int = audioExtractor.getTrackCount()
//        for (i in 0 until audioTrackCount) {
//            audioFormat = audioExtractor.getTrackFormat(i)
//            val mimeType = audioFormat.getString(MediaFormat.KEY_MIME)
//            if (mimeType!!.startsWith("audio/")) {
//                audioTrackIndex = i
//                break
//            }
//        }
//
//        if (audioTrackIndex < 0) {
//            Log.e("TAG", "Error input file:: No Audio track")
//            return
//        }
//    }
//
//    fun app3(){
//        val videoBufferInfo = MediaCodec.BufferInfo()
//     var   mediaMuxer = MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
//        val writeVideoTrackIndex: Int = mediaMuxer.addTrack(videoFormat!!)
//        val writeAudioTrackIndex: Int = mediaMuxer.addTrack(audioFormat!!)
//        mediaMuxer.start()
//
//        val byteBuffer: ByteBuffer = ByteBuffer.allocate(frameMaxInputSize)
//        videoExtractor.unselectTrack(videoTrackIndex)
//        videoExtractor.selectTrack(videoTrackIndex)
//
//        while (true) {
//            val readVideoSampleSize: Int = videoExtractor.readSampleData(byteBuffer, 0)
//            if (readVideoSampleSize < 0) {
//                videoExtractor.unselectTrack(videoTrackIndex)
//                break
//            }
//            val videoSampleTime: Long = videoExtractor.getSampleTime()
//            videoBufferInfo.size = readVideoSampleSize
//            videoBufferInfo.presentationTimeUs = videoSampleTime
//            //videoBufferInfo.presentationTimeUs += 1000 * 1000 / frameRate;
//            videoBufferInfo.offset = 0
//            videoBufferInfo.flags = videoExtractor.getSampleFlags()
//            mediaMuxer.writeSampleData(writeVideoTrackIndex, byteBuffer, videoBufferInfo)
//            videoExtractor.advance()
//        }
//    }
//
//fun app4(){
//    var audioPresentationTimeUs: Long = 0
//    val audioBufferInfo = MediaCodec.BufferInfo()
//    audioExtractor.selectTrack(audioTrackIndex)
//    /*
//     * the last audio presentation time.
//     */
//    /*
//     * the last audio presentation time.
//     */
//    var lastEndAudioTimeUs: Long = 0
//    while (true) {
//        val readAudioSampleSize = audioExtractor.readSampleData(byteBuffer, 0)
//        if (readAudioSampleSize < 0) {
//            //if end of the stream, unselect
//            audioExtractor.unselectTrack(audioTrackIndex)
//            if (audioPresentationTimeUs >= videoDuration) {
//                //if has reach the end of the video time ,just exit
//                break
//            } else {
//                //if not the end of the video time, just repeat.
//                lastEndAudioTimeUs += audioPresentationTimeUs
//                audioExtractor.selectTrack(audioTrackIndex)
//                continue
//            }
//        }
//        val audioSampleTime = audioExtractor.sampleTime
//        audioBufferInfo.size = readAudioSampleSize
//        audioBufferInfo.presentationTimeUs = audioSampleTime + lastEndAudioTimeUs
//        if (audioBufferInfo.presentationTimeUs > videoDuration) {
//            audioExtractor.unselectTrack(audioTrackIndex)
//            break
//        }
//        audioPresentationTimeUs = audioBufferInfo.presentationTimeUs
//        audioBufferInfo.offset = 0
//        audioBufferInfo.flags = audioExtractor.sampleFlags
//        mediaMuxer.writeSampleData(writeAudioTrackIndex, byteBuffer, audioBufferInfo)
//        audioExtractor.advance()
//    }
//}
//
//    fun app5(){
//        if (mediaMuxer != null) {
//            try {
//                mediaMuxer.stop()
//                mediaMuxer.release()
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
//        }
//
//        if (videoExtractor != null) {
//            try {
//                videoExtractor.release()
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
//        }
//
//        if (audioExtractor != null) {
//            try {
//                audioExtractor.release()
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
//        }
//    }
//}